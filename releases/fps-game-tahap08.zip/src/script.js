/* ============================================================
   script.js — FPS Game Tahap 08: Map/Arena Minimalis Pertama
   Bug fixes: ALL objects collidable (no pass-through)
   + Tahap 01-07 + 50x50 maze-like arena
   ============================================================ */

// ── Konfigurasi ──────────────────────────────────────────────
const CONFIG = {
  // Camera
  cameraFOV: 75,
  cameraNear: 0.1,
  cameraFar: 1000,
  cameraStartY: 1.7,
  cameraStartZ: 0,

  // Scene
  backgroundColor: 0x222222,
  groundWidth: 60,
  groundHeight: 60,
  groundColor: 0x555555,

  // Renderer
  antialias: true,

  // Grid (disabled — arena provides visual reference)
  showGrid: false,
  gridSize: 60,
  gridDivisions: 60,
  gridColor1: 0x444444,
  gridColor2: 0x888888,

  // ── Tahap 02: Movement ────────────────────────────────────
  walkSpeed: 5.0,
  playerHeight: 1.7,
  movementSmoothing: 0.85,

  // ── Tahap 06: Mouse Look ──────────────────────────────────
  mouseSensitivity: 0.002,
  mouseSensitivityMin: 0.0005,
  mouseSensitivityMax: 0.01,
  mouseSensitivityStep: 0.0005,
  mouseSmoothing: 0.6,
  mouseSmoothBuffer: 4,

  // ── Tahap 03: Jump Physics ────────────────────────────────
  gravity: -9.8,
  jumpForce: 5.0,
  groundLevel: 1.7,

  // ── Tahap 04: Sprint & Stamina ────────────────────────────
  sprintSpeed: 9.0,
  staminaMax: 100,
  staminaDrain: 20,
  staminaRecovery: 10,

  // ── Tahap 05: Crouch & Crawl ──────────────────────────────
  crouchSpeed: 3.0,
  crawlSpeed: 2.0,
  crouchHeight: 0.9,
  crawlHeight: 0.4,
  standHeight: 1.7,
  crouchTransitionLerp: 0.12,

  // ── Tahap 07: Collision Detection ─────────────────────────
  playerRadius: 0.5,
  collisionEnabled: true,

  // ── Tahap 08: Arena Map ───────────────────────────────────
  arenaSize: 50,
  wallHeight: 3,
  wallThickness: 0.5,
};

// ── Variabel Global ─────────────────────────────────────────
let scene, camera, renderer;
let clock;

// ── Input State ─────────────────────────────────────────────
const keys = {
  w: false, a: false, s: false, d: false,
  space: false, shift: false, c: false, control: false,
};

const velocity = new THREE.Vector3(0, 0, 0);
let velocityY = 0;
let isGrounded = true;

// ── Sprint & Stamina ───────────────────────────────────────
let stamina = CONFIG.staminaMax;
let isSprinting = false;
let isExhausted = false;
let exhaustionTimer = 0;
const EXHAUSTION_COOLDOWN = 1.5;

// ── Crouch & Crawl ─────────────────────────────────────────
let stance = 'standing';
let targetCameraY = CONFIG.standHeight;
let crouchJustPressed = false;

// ── Mouse Look ─────────────────────────────────────────────
let yaw = 0;
let pitch = 0;
const PITCH_LIMIT = Math.PI / 2 - 0.01;
let mouseBufferX = [];
let mouseBufferY = [];
let mouseSensitivity = CONFIG.mouseSensitivity;

// Pointer Lock & Fullscreen state
let isPointerLocked = false;
let isFullscreen = false;

// ── Collision Detection (Tahap 07) ─────────────────────────
let collidableBoxes = [];

// ── DOM Elements ────────────────────────────────────────────
const debugInfo = document.getElementById('debug-info');
const loadingScreen = document.getElementById('loading-screen');
const lockPrompt = document.getElementById('lock-prompt');
const jumpIndicator = document.getElementById('jump-indicator');
const staminaBar = document.getElementById('stamina-bar');
const staminaFill = document.getElementById('stamina-fill');
const staminaText = document.getElementById('stamina-text');
const crouchIndicator = document.getElementById('crouch-indicator');
const crosshair = document.getElementById('crosshair');
const sensitivityIndicator = document.getElementById('sensitivity-indicator');

// ── Input Handling ──────────────────────────────────────────
function setupInputHandlers() {
  window.addEventListener('keydown', (e) => {
    if (isPointerLocked) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }

    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = true;
    } else if (key === 'shift') {
      keys.shift = true;
    } else if (key === 'control') {
      keys.control = true;
    } else if (key === 'c') {
      if (!keys.c) crouchJustPressed = true;
      keys.c = true;
    } else if (key in keys) {
      keys[key] = true;
    }

    if (isPointerLocked) {
      if (key === '=' || key === '+' || key === 'numpadadd') {
        mouseSensitivity = Math.min(CONFIG.mouseSensitivityMax, mouseSensitivity + CONFIG.mouseSensitivityStep);
        showSensitivityIndicator();
      } else if (key === '-' || key === 'numpadsubtract') {
        mouseSensitivity = Math.max(CONFIG.mouseSensitivityMin, mouseSensitivity - CONFIG.mouseSensitivityStep);
        showSensitivityIndicator();
      }
    }
  }, true); // capture phase

  window.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();
    if (key === ' ' || key === 'spacebar') keys.space = false;
    else if (key === 'shift') keys.shift = false;
    else if (key === 'control') keys.control = false;
    else if (key === 'c') keys.c = false;
    else if (key in keys) keys[key] = false;
  });

  window.addEventListener('blur', () => {
    Object.keys(keys).forEach(k => keys[k] = false);
  });

  window.addEventListener('beforeunload', (e) => {
    if (isPointerLocked) {
      e.preventDefault();
      e.returnValue = 'Game masih berjalan! Yakin ingin keluar?';
      return e.returnValue;
    }
  });

  const canvas = renderer.domElement;

  async function requestLock() {
    if (!isPointerLocked) {
      try {
        if (!document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
          isFullscreen = true;
        }
      } catch (err) {}

      canvas.requestPointerLock();

      try {
        if (navigator.keyboard && navigator.keyboard.lock) {
          await navigator.keyboard.lock();
        }
      } catch (err) {}
    }
  }

  canvas.addEventListener('click', requestLock);
  if (lockPrompt) {
    lockPrompt.addEventListener('click', requestLock);
  }

  document.addEventListener('pointerlockchange', () => {
    isPointerLocked = document.pointerLockElement === canvas;
    if (isPointerLocked) {
      if (lockPrompt) lockPrompt.style.display = 'none';
    } else {
      if (lockPrompt) lockPrompt.style.display = 'flex';
      keys.shift = false;
      keys.c = false;
      keys.control = false;
      if (stance !== 'standing') {
        stance = 'standing';
        targetCameraY = CONFIG.standHeight;
      }
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
    }
  });

  document.addEventListener('fullscreenchange', () => {
    isFullscreen = !!document.fullscreenElement;
  });

  document.addEventListener('mousemove', (e) => {
    if (!isPointerLocked) return;

    const rawX = e.movementX || 0;
    const rawY = e.movementY || 0;

    mouseBufferX.push(rawX);
    mouseBufferY.push(rawY);
    while (mouseBufferX.length > CONFIG.mouseSmoothBuffer) {
      mouseBufferX.shift();
      mouseBufferY.shift();
    }

    const smoothX = mouseBufferX.reduce((a, b) => a + b, 0) / mouseBufferX.length;
    const smoothY = mouseBufferY.reduce((a, b) => a + b, 0) / mouseBufferY.length;

    const sm = CONFIG.mouseSmoothing;
    const finalX = rawX * (1 - sm) + smoothX * sm;
    const finalY = rawY * (1 - sm) + smoothY * sm;

    yaw -= finalX * mouseSensitivity;
    pitch -= finalY * mouseSensitivity;
    pitch = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitch));

    camera.rotation.order = 'YXZ';
    camera.rotation.set(pitch, yaw, 0);
  });
}

// ── Sensitivity Indicator ──────────────────────────────────
let sensitivityTimeout = null;
function showSensitivityIndicator() {
  if (sensitivityIndicator) {
    const pct = ((mouseSensitivity - CONFIG.mouseSensitivityMin) /
                 (CONFIG.mouseSensitivityMax - CONFIG.mouseSensitivityMin) * 100);
    sensitivityIndicator.textContent = `SENS: ${mouseSensitivity.toFixed(4)} (${Math.round(pct)}%)`;
    sensitivityIndicator.style.opacity = '1';
    sensitivityIndicator.style.display = 'block';
    if (sensitivityTimeout) clearTimeout(sensitivityTimeout);
    sensitivityTimeout = setTimeout(() => {
      if (sensitivityIndicator) {
        sensitivityIndicator.style.opacity = '0';
        setTimeout(() => { if (sensitivityIndicator) sensitivityIndicator.style.display = 'none'; }, 400);
      }
    }, 2000);
  }
}

// ── Dynamic Crosshair ──────────────────────────────────────
function updateCrosshair() {
  if (!crosshair) return;

  const isMoving = keys.w || keys.a || keys.s || keys.d;
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);

  let spread = 0;
  if (isSprinting) spread = 8;
  else if (speed > 2) spread = 4;
  else if (isMoving) spread = 2;

  if (stance === 'crouching') spread = Math.max(0, spread - 2);
  if (stance === 'crawling') spread = 0;

  crosshair.style.setProperty('--spread', spread + 'px');

  if (stance === 'crawling') {
    crosshair.style.setProperty('--ch-color', 'rgba(0, 255, 100, 0.9)');
  } else if (stance === 'crouching') {
    crosshair.style.setProperty('--ch-color', 'rgba(100, 255, 100, 0.9)');
  } else if (isSprinting) {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 200, 50, 0.9)');
  } else {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 255, 255, 0.8)');
  }
}

// ── Inisialisasi ────────────────────────────────────────────
function init() {
  clock = new THREE.Clock();

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(CONFIG.backgroundColor);
  scene.fog = new THREE.Fog(CONFIG.backgroundColor, 30, 60);

  // Camera — start in center of arena
  camera = new THREE.PerspectiveCamera(
    CONFIG.cameraFOV, window.innerWidth / window.innerHeight,
    CONFIG.cameraNear, CONFIG.cameraFar
  );
  camera.position.set(0, CONFIG.cameraStartY, 0);
  camera.rotation.order = 'YXZ';
  camera.lookAt(0, CONFIG.cameraStartY, -1);
  yaw = 0;
  pitch = 0;

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: CONFIG.antialias });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Ground Plane
  const groundGeometry = new THREE.PlaneGeometry(CONFIG.groundWidth, CONFIG.groundHeight);
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: CONFIG.groundColor, side: THREE.DoubleSide, roughness: 0.9, metalness: 0.1,
  });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  ground.name = 'ground';
  scene.add(ground);

  // Grid Helper (disabled for arena)
  if (CONFIG.showGrid) {
    const grid = new THREE.GridHelper(CONFIG.gridSize, CONFIG.gridDivisions, CONFIG.gridColor1, CONFIG.gridColor2);
    grid.position.y = 0.01;
    grid.name = 'grid';
    scene.add(grid);
  }

  // Tahap 08: Build Arena Map
  buildArenaMap();

  // Lights — ambient + directional sun
  scene.add(new THREE.AmbientLight(0xffffff, 0.5));
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.9);
  dirLight.position.set(30, 50, 20);
  scene.add(dirLight);

  // Extra point light in center of arena
  const pointLight = new THREE.PointLight(0xffffcc, 0.4, 30);
  pointLight.position.set(0, 5, 0);
  scene.add(pointLight);

  // Setup Input
  setupInputHandlers();

  // Resize Handler
  window.addEventListener('resize', onWindowResize);

  // Hide Loading Screen
  if (loadingScreen) {
    loadingScreen.classList.add('hidden');
    setTimeout(() => { if (loadingScreen && loadingScreen.parentNode) loadingScreen.parentNode.removeChild(loadingScreen); }, 600);
  }

  if (lockPrompt) lockPrompt.style.display = 'flex';

  // Start Render Loop
  animate();
}

// ── Tahap 08: Arena Map Builder ────────────────────────────
// 50x50 maze-like arena with:
// - 1 large open area in center (~15x15)
// - 4 corridors connecting open area
// - 4 small rooms (~5x5) in corners
// - 2 choke points (~2 unit wide)
// - All walls collidable
function buildArenaMap() {
  const H = CONFIG.wallHeight;       // 3
  const T = CONFIG.wallThickness;    // 0.5
  const S = CONFIG.arenaSize;        // 50
  const halfS = S / 2;              // 25

  // Wall materials — various grays & cream tones
  const wallMats = {
    outer: new THREE.MeshStandardMaterial({ color: 0x777777, roughness: 0.8, metalness: 0.1 }),
    inner: new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7, metalness: 0.1 }),
    room:  new THREE.MeshStandardMaterial({ color: 0x999988, roughness: 0.75, metalness: 0.1 }), // cream
    choke: new THREE.MeshStandardMaterial({ color: 0x666666, roughness: 0.8, metalness: 0.2 }),
    pillar: new THREE.MeshStandardMaterial({ color: 0x888877, roughness: 0.7, metalness: 0.15 }),
    cover: new THREE.MeshStandardMaterial({ color: 0x7a7a6e, roughness: 0.75, metalness: 0.1 }),
  };

  // Helper: add a wall box and register it as collidable
  function addWall(width, height, depth, x, y, z, name, mat) {
    const geo = new THREE.BoxGeometry(width, height, depth);
    const mesh = new THREE.Mesh(geo, mat || wallMats.inner);
    mesh.position.set(x, y, z);
    mesh.name = name;
    mesh.userData.collidable = true;
    scene.add(mesh);
    return mesh;
  }

  // Helper: add a cylinder pillar and register as collidable (approximate with AABB)
  function addPillar(radius, height, x, y, z, name, mat) {
    const geo = new THREE.CylinderGeometry(radius, radius, height, 8);
    const mesh = new THREE.Mesh(geo, mat || wallMats.pillar);
    mesh.position.set(x, y, z);
    mesh.name = name;
    mesh.userData.collidable = true;
    scene.add(mesh);
    return mesh;
  }

  // ══════════════════════════════════════════════════════════
  // 1. OUTER BOUNDARY WALLS (enclose the 50x50 arena)
  // ══════════════════════════════════════════════════════════
  // North wall (z = -25)
  addWall(S, H, T, 0, H/2, -halfS, 'outer_north', wallMats.outer);
  // South wall (z = +25)
  addWall(S, H, T, 0, H/2, halfS, 'outer_south', wallMats.outer);
  // West wall (x = -25)
  addWall(T, H, S, -halfS, H/2, 0, 'outer_west', wallMats.outer);
  // East wall (x = +25)
  addWall(T, H, S, halfS, H/2, 0, 'outer_east', wallMats.outer);

  // ══════════════════════════════════════════════════════════
  // 2. CENTRAL OPEN ARENA (~15x15 area, walls around it)
  //    Arena center at (0,0). Arena spans x: -7.5 to 7.5, z: -7.5 to 7.5
  //    But with 4 openings (corridors) on each side
  // ══════════════════════════════════════════════════════════
  const arenaHalf = 7.5;
  const corridorWidth = 3;   // opening width for corridors
  const corridorLen = 6;     // corridor length from arena edge

  // North side of arena: wall from x=-7.5 to x=-1.5, gap -1.5 to 1.5, wall 1.5 to 7.5
  // (gap at center for north corridor)
  addWall(arenaHalf - corridorWidth/2, H, T,
    -(arenaHalf + corridorWidth/2) / 2 + (corridorWidth/2) / 2,
    // Simplified: left segment center x = (-7.5 + (-1.5)) / 2 = -4.5
    H/2, -arenaHalf, 'arena_n_left', wallMats.inner);
  // Actually let me recalculate properly:
  // Left segment: x from -7.5 to -1.5, width = 6, center x = -4.5
  addWall(6, H, T, -4.5, H/2, -arenaHalf, 'arena_n_left', wallMats.inner);
  // Right segment: x from 1.5 to 7.5, width = 6, center x = 4.5
  addWall(6, H, T, 4.5, H/2, -arenaHalf, 'arena_n_right', wallMats.inner);

  // South side of arena: gap at center for south corridor
  addWall(6, H, T, -4.5, H/2, arenaHalf, 'arena_s_left', wallMats.inner);
  addWall(6, H, T, 4.5, H/2, arenaHalf, 'arena_s_right', wallMats.inner);

  // West side of arena: gap at center for west corridor
  // z from -7.5 to -1.5 and 1.5 to 7.5
  addWall(T, H, 6, -arenaHalf, H/2, -4.5, 'arena_w_top', wallMats.inner);
  addWall(T, H, 6, -arenaHalf, H/2, 4.5, 'arena_w_bottom', wallMats.inner);

  // East side of arena: gap at center for east corridor
  addWall(T, H, 6, arenaHalf, H/2, -4.5, 'arena_e_top', wallMats.inner);
  addWall(T, H, 6, arenaHalf, H/2, 4.5, 'arena_e_bottom', wallMats.inner);

  // ══════════════════════════════════════════════════════════
  // 3. CORRIDORS (4 corridors extending from arena center to edges)
  // ══════════════════════════════════════════════════════════

  // --- North Corridor: z from -7.5 to -(7.5+corridorLen) = -13.5
  //    Width = 3 (x: -1.5 to 1.5)
  //    Left wall at x = -1.5
  addWall(T, H, corridorLen, -corridorWidth/2, H/2, -arenaHalf - corridorLen/2, 'corr_n_left', wallMats.inner);
  //    Right wall at x = 1.5
  addWall(T, H, corridorLen, corridorWidth/2, H/2, -arenaHalf - corridorLen/2, 'corr_n_right', wallMats.inner);
  //    End wall (with small gap for passage)
  addWall(1, H, T, -1, H/2, -arenaHalf - corridorLen, 'corr_n_end_l', wallMats.inner);
  addWall(1, H, T, 1, H/2, -arenaHalf - corridorLen, 'corr_n_end_r', wallMats.inner);

  // --- South Corridor: z from 7.5 to 13.5
  addWall(T, H, corridorLen, -corridorWidth/2, H/2, arenaHalf + corridorLen/2, 'corr_s_left', wallMats.inner);
  addWall(T, H, corridorLen, corridorWidth/2, H/2, arenaHalf + corridorLen/2, 'corr_s_right', wallMats.inner);
  addWall(1, H, T, -1, H/2, arenaHalf + corridorLen, 'corr_s_end_l', wallMats.inner);
  addWall(1, H, T, 1, H/2, arenaHalf + corridorLen, 'corr_s_end_r', wallMats.inner);

  // --- West Corridor: x from -7.5 to -13.5
  addWall(corridorLen, H, T, -arenaHalf - corridorLen/2, H/2, -corridorWidth/2, 'corr_w_top', wallMats.inner);
  addWall(corridorLen, H, T, -arenaHalf - corridorLen/2, H/2, corridorWidth/2, 'corr_w_bottom', wallMats.inner);
  addWall(T, H, 1, -arenaHalf - corridorLen, H/2, -1, 'corr_w_end_t', wallMats.inner);
  addWall(T, H, 1, -arenaHalf - corridorLen, H/2, 1, 'corr_w_end_b', wallMats.inner);

  // --- East Corridor: x from 7.5 to 13.5
  addWall(corridorLen, H, T, arenaHalf + corridorLen/2, H/2, -corridorWidth/2, 'corr_e_top', wallMats.inner);
  addWall(corridorLen, H, T, arenaHalf + corridorLen/2, H/2, corridorWidth/2, 'corr_e_bottom', wallMats.inner);
  addWall(T, H, 1, arenaHalf + corridorLen, H/2, -1, 'corr_e_end_t', wallMats.inner);
  addWall(T, H, 1, arenaHalf + corridorLen, H/2, 1, 'corr_e_end_b', wallMats.inner);

  // ══════════════════════════════════════════════════════════
  // 4. SMALL ROOMS (~5x5) IN CORNERS
  // ══════════════════════════════════════════════════════════

  // Room dimensions: 5x5 inner space, walls at edges
  const roomSize = 5;
  const roomDoorWidth = 2;  // door opening

  // --- NW Room: center at (-20, -20), spans x: -22.5 to -17.5, z: -22.5 to -17.5
  const nw_cx = -20, nw_cz = -20;
  // North wall with door at center
  addWall((roomSize - roomDoorWidth) / 2, H, T, nw_cx - roomDoorWidth/2 - (roomSize - roomDoorWidth)/4, H/2, nw_cz - roomSize/2, 'room_nw_n_l', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, nw_cx + roomDoorWidth/2 + (roomSize - roomDoorWidth)/4, H/2, nw_cz - roomSize/2, 'room_nw_n_r', wallMats.room);
  // South wall (solid)
  addWall(roomSize, H, T, nw_cx, H/2, nw_cz + roomSize/2, 'room_nw_s', wallMats.room);
  // West wall (solid)
  addWall(T, H, roomSize, nw_cx - roomSize/2, H/2, nw_cz, 'room_nw_w', wallMats.room);
  // East wall (solid)
  addWall(T, H, roomSize, nw_cx + roomSize/2, H/2, nw_cz, 'room_nw_e', wallMats.room);
  // Cover box inside room
  addWall(1.5, 1.2, 1.5, nw_cx - 1, 0.6, nw_cz + 0.5, 'room_nw_cover', wallMats.cover);

  // --- NE Room: center at (20, -20)
  const ne_cx = 20, ne_cz = -20;
  addWall((roomSize - roomDoorWidth) / 2, H, T, ne_cx - roomDoorWidth/2 - (roomSize - roomDoorWidth)/4, H/2, ne_cz - roomSize/2, 'room_ne_n_l', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, ne_cx + roomDoorWidth/2 + (roomSize - roomDoorWidth)/4, H/2, ne_cz - roomSize/2, 'room_ne_n_r', wallMats.room);
  addWall(roomSize, H, T, ne_cx, H/2, ne_cz + roomSize/2, 'room_ne_s', wallMats.room);
  addWall(T, H, roomSize, ne_cx - roomSize/2, H/2, ne_cz, 'room_ne_w', wallMats.room);
  addWall(T, H, roomSize, ne_cx + roomSize/2, H/2, ne_cz, 'room_ne_e', wallMats.room);
  addWall(1.5, 1.2, 1.5, ne_cx + 1, 0.6, ne_cz + 0.5, 'room_ne_cover', wallMats.cover);

  // --- SW Room: center at (-20, 20)
  const sw_cx = -20, sw_cz = 20;
  addWall(roomSize, H, T, sw_cx, H/2, sw_cz - roomSize/2, 'room_sw_n', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, sw_cx - roomDoorWidth/2 - (roomSize - roomDoorWidth)/4, H/2, sw_cz + roomSize/2, 'room_sw_s_l', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, sw_cx + roomDoorWidth/2 + (roomSize - roomDoorWidth)/4, H/2, sw_cz + roomSize/2, 'room_sw_s_r', wallMats.room);
  addWall(T, H, roomSize, sw_cx - roomSize/2, H/2, sw_cz, 'room_sw_w', wallMats.room);
  addWall(T, H, roomSize, sw_cx + roomSize/2, H/2, sw_cz, 'room_sw_e', wallMats.room);
  addWall(1.5, 1.2, 1.5, sw_cx - 1, 0.6, sw_cz - 0.5, 'room_sw_cover', wallMats.cover);

  // --- SE Room: center at (20, 20)
  const se_cx = 20, se_cz = 20;
  addWall(roomSize, H, T, se_cx, H/2, se_cz - roomSize/2, 'room_se_n', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, se_cx - roomDoorWidth/2 - (roomSize - roomDoorWidth)/4, H/2, se_cz + roomSize/2, 'room_se_s_l', wallMats.room);
  addWall((roomSize - roomDoorWidth) / 2, H, T, se_cx + roomDoorWidth/2 + (roomSize - roomDoorWidth)/4, H/2, se_cz + roomSize/2, 'room_se_s_r', wallMats.room);
  addWall(T, H, roomSize, se_cx - roomSize/2, H/2, se_cz, 'room_se_w', wallMats.room);
  addWall(T, H, roomSize, se_cx + roomSize/2, H/2, se_cz, 'room_se_e', wallMats.room);
  addWall(1.5, 1.2, 1.5, se_cx + 1, 0.6, se_cz - 0.5, 'room_se_cover', wallMats.cover);

  // ══════════════════════════════════════════════════════════
  // 5. CHOKE POINTS (2 narrow passages ~2 unit wide)
  // ══════════════════════════════════════════════════════════

  // Choke Point 1: Between north corridor end and NW room
  // Located at z ≈ -16, x from -6 to -12
  // Narrow passage: 2 units wide at x = -9
  // Left side wall
  addWall(4, H, T, -6, H/2, -16, 'choke1_wall_a', wallMats.choke);
  addWall(4, H, T, -12, H/2, -16, 'choke1_wall_b', wallMats.choke);
  // Funnel walls
  addWall(T, H, 3, -8, H/2, -17.5, 'choke1_funnel_l', wallMats.choke);
  addWall(T, H, 3, -10, H/2, -17.5, 'choke1_funnel_r', wallMats.choke);

  // Choke Point 2: Between east corridor end and NE room
  // Located at x ≈ 16, z from -6 to -12
  addWall(T, H, 4, 16, H/2, -6, 'choke2_wall_a', wallMats.choke);
  addWall(T, H, 4, 16, H/2, -12, 'choke2_wall_b', wallMats.choke);
  // Funnel walls
  addWall(3, H, T, 17.5, H/2, -8, 'choke2_funnel_l', wallMats.choke);
  addWall(3, H, T, 17.5, H/2, -10, 'choke2_funnel_r', wallMats.choke);

  // ══════════════════════════════════════════════════════════
  // 6. COVER OBJECTS & PILLARS (inside arena & corridors)
  // ══════════════════════════════════════════════════════════

  // Pillars in central arena (4 pillars around center)
  addPillar(0.6, H, -3, H/2, -3, 'arena_pillar_nw');
  addPillar(0.6, H, 3, H/2, -3, 'arena_pillar_ne');
  addPillar(0.6, H, -3, H/2, 3, 'arena_pillar_sw');
  addPillar(0.6, H, 3, H/2, 3, 'arena_pillar_se');

  // Cover boxes in arena (low walls for hiding)
  addWall(3, 1.5, T, 0, 0.75, -5, 'arena_cover_n', wallMats.cover);
  addWall(T, 1.5, 3, 5, 0.75, 0, 'arena_cover_e', wallMats.cover);
  addWall(3, 1.5, T, 0, 0.75, 5, 'arena_cover_s', wallMats.cover);
  addWall(T, 1.5, 3, -5, 0.75, 0, 'arena_cover_w', wallMats.cover);

  // Cover in corridors
  addWall(1.5, 1.2, 1.5, 0, 0.6, -arenaHalf - corridorLen/2, 'corr_n_cover', wallMats.cover);
  addWall(1.5, 1.2, 1.5, 0, 0.6, arenaHalf + corridorLen/2, 'corr_s_cover', wallMats.cover);
  addWall(1.5, 1.2, 1.5, -arenaHalf - corridorLen/2, 0.6, 0, 'corr_w_cover', wallMats.cover);
  addWall(1.5, 1.2, 1.5, arenaHalf + corridorLen/2, 0.6, 0, 'corr_e_cover', wallMats.cover);

  // Additional pillars in open areas between corridors and rooms
  addPillar(0.5, H, -15, H/2, -15, 'mid_pillar_nw');
  addPillar(0.5, H, 15, H/2, -15, 'mid_pillar_ne');
  addPillar(0.5, H, -15, H/2, 15, 'mid_pillar_sw');
  addPillar(0.5, H, 15, H/2, 15, 'mid_pillar_se');

  // Low walls connecting rooms to corridor areas
  addWall(4, H, T, -9, H/2, -13.5, 'midwall_nw_n', wallMats.inner);
  addWall(4, H, T, 9, H/2, -13.5, 'midwall_ne_n', wallMats.inner);
  addWall(T, H, 4, -13.5, H/2, -9, 'midwall_nw_w', wallMats.inner);
  addWall(T, H, 4, 13.5, H/2, -9, 'midwall_ne_e', wallMats.inner);
  addWall(4, H, T, -9, H/2, 13.5, 'midwall_sw_s', wallMats.inner);
  addWall(4, H, T, 9, H/2, 13.5, 'midwall_se_s', wallMats.inner);
  addWall(T, H, 4, -13.5, H/2, 9, 'midwall_sw_w', wallMats.inner);
  addWall(T, H, 4, 13.5, H/2, 9, 'midwall_se_e', wallMats.inner);

  // ══════════════════════════════════════════════════════════
  // 7. Build collision boxes from all collidable meshes
  // ══════════════════════════════════════════════════════════
  rebuildCollisionBoxes();
}

// ── Rebuild Collision AABBs dari scene ──────────────────────
function rebuildCollisionBoxes() {
  collidableBoxes = [];
  scene.traverse((obj) => {
    if (obj.userData && obj.userData.collidable && obj.isMesh) {
      const box = new THREE.Box3().setFromObject(obj);
      collidableBoxes.push({
        name: obj.name,
        minX: box.min.x, maxX: box.max.x,
        minY: box.min.y, maxY: box.max.y,
        minZ: box.min.z, maxZ: box.max.z,
      });
    }
  });
}

// ── Collision Check (AABB vs circle on XZ plane) ───────────
function checkCollision(newX, newZ, radius) {
  const r = radius;
  const playerY = camera.position.y;
  const playerMinY = playerY - 0.1;  // slight tolerance
  const playerMaxY = playerY + 0.1;

  for (let i = 0; i < collidableBoxes.length; i++) {
    const box = collidableBoxes[i];

    // Y-axis check: only collide if player overlaps with box vertically
    if (playerMaxY < box.minY || playerMinY > box.maxY) continue;

    // XZ plane: circle vs AABB
    const closestX = Math.max(box.minX, Math.min(newX, box.maxX));
    const closestZ = Math.max(box.minZ, Math.min(newZ, box.maxZ));

    const dx = newX - closestX;
    const dz = newZ - closestZ;
    const distSq = dx * dx + dz * dz;

    if (distSq < r * r) {
      const dist = Math.sqrt(Math.max(distSq, 0.0001));
      return {
        collided: true,
        pushX: dx / dist,
        pushZ: dz / dist,
        overlap: r - dist,
        boxName: box.name,
      };
    }
  }
  return { collided: false };
}

// ── Collision Resolution with Wall Slide ────────────────────
function resolveCollision(newX, newZ, radius) {
  const result = checkCollision(newX, newZ, radius);
  if (!result.collided) return { x: newX, z: newZ, collided: false };

  const pushX = result.pushX * result.overlap;
  const pushZ = result.pushZ * result.overlap;

  let resolvedX = newX + pushX;
  let resolvedZ = newZ + pushZ;

  const recheck = checkCollision(resolvedX, resolvedZ, radius);
  if (recheck.collided) {
    resolvedX += recheck.pushX * recheck.overlap;
    resolvedZ += recheck.pushZ * recheck.overlap;
  }

  const dot = velocity.x * result.pushX + velocity.z * result.pushZ;
  if (dot < 0) {
    velocity.x -= dot * result.pushX;
    velocity.z -= dot * result.pushZ;
  }

  return { x: resolvedX, z: resolvedZ, collided: true };
}

// ── Resize Handler ──────────────────────────────────────────
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ── Crouch / Crawl ─────────────────────────────────────────
function updateCrouch(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  if (crouchJustPressed) {
    crouchJustPressed = false;
    switch (stance) {
      case 'standing':  stance = 'crouching'; targetCameraY = CONFIG.crouchHeight; break;
      case 'crouching': stance = 'crawling';  targetCameraY = CONFIG.crawlHeight;  break;
      case 'crawling':  stance = 'standing';  targetCameraY = CONFIG.standHeight;  break;
    }
  }

  if (keys.control && stance !== 'crawling') {
    stance = 'crawling';
    targetCameraY = CONFIG.crawlHeight;
  }

  if (isGrounded) {
    const currentY = camera.position.y;
    const lerpFactor = 1 - Math.pow(1 - CONFIG.crouchTransitionLerp, dt * 60);
    camera.position.y = currentY + (targetCameraY - currentY) * lerpFactor;
    if (Math.abs(camera.position.y - targetCameraY) < 0.01) camera.position.y = targetCameraY;
    CONFIG.groundLevel = targetCameraY;
  }

  if (crouchIndicator) {
    switch (stance) {
      case 'standing':  crouchIndicator.textContent = 'STANDING';  crouchIndicator.className = 'standing';  break;
      case 'crouching': crouchIndicator.textContent = 'CROUCHING'; crouchIndicator.className = 'crouching'; break;
      case 'crawling':  crouchIndicator.textContent = 'CRAWLING';  crouchIndicator.className = 'crawling';  break;
    }
  }
}

// ── Sprint & Stamina ───────────────────────────────────────
function updateSprint(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);
  const isMoving = keys.w || keys.a || keys.s || keys.d;

  if (isExhausted) {
    exhaustionTimer -= dt;
    if (exhaustionTimer <= 0) { isExhausted = false; exhaustionTimer = 0; }
  }

  const canSprint = keys.shift && isGrounded && stamina > 0 && isMoving && !isExhausted && stance === 'standing';

  if (canSprint) {
    isSprinting = true;
    stamina -= CONFIG.staminaDrain * dt;
    if (stamina <= 0) { stamina = 0; isExhausted = true; exhaustionTimer = EXHAUSTION_COOLDOWN; }
  } else {
    isSprinting = false;
    stamina += CONFIG.staminaRecovery * dt;
    if (stamina > CONFIG.staminaMax) stamina = CONFIG.staminaMax;
  }

  if (staminaFill) {
    const pct = (stamina / CONFIG.staminaMax) * 100;
    staminaFill.style.width = pct + '%';
    staminaFill.style.background = pct > 60 ? '#00ff00' : pct > 30 ? '#ffaa00' : '#ff3300';
  }
  if (staminaText) staminaText.textContent = Math.round(stamina) + '%';
  if (staminaBar) {
    if (stamina <= 0 && keys.shift) staminaBar.classList.add('exhausted');
    else staminaBar.classList.remove('exhausted');
  }
}

// ── Horizontal Movement + Collision ─────────────────────────
function updateMovement(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  let currentSpeed;
  if (stance === 'crawling') currentSpeed = CONFIG.crawlSpeed;
  else if (stance === 'crouching') currentSpeed = CONFIG.crouchSpeed;
  else if (isSprinting) currentSpeed = CONFIG.sprintSpeed;
  else currentSpeed = CONFIG.walkSpeed;

  const cameraDirection = new THREE.Vector3();
  camera.getWorldDirection(cameraDirection);
  const forwardXZ = new THREE.Vector3(cameraDirection.x, 0, cameraDirection.z);
  const forwardLen = forwardXZ.length();

  let forward, right;
  if (forwardLen > 0.001) {
    forward = forwardXZ.normalize();
    right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  } else {
    forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  }

  const targetVelocity = new THREE.Vector3(0, 0, 0);
  if (keys.w) targetVelocity.add(forward);
  if (keys.s) targetVelocity.sub(forward);
  if (keys.d) targetVelocity.add(right);
  if (keys.a) targetVelocity.sub(right);
  if (targetVelocity.lengthSq() > 0) targetVelocity.normalize();
  targetVelocity.multiplyScalar(currentSpeed);

  const smoothing = CONFIG.movementSmoothing;
  const lerpFactor = 1 - Math.pow(smoothing, dt * 60);
  velocity.x += (targetVelocity.x - velocity.x) * lerpFactor;
  velocity.z += (targetVelocity.z - velocity.z) * lerpFactor;

  let newX = camera.position.x + velocity.x * dt;
  let newZ = camera.position.z + velocity.z * dt;

  if (CONFIG.collisionEnabled && collidableBoxes.length > 0) {
    const result = resolveCollision(newX, newZ, CONFIG.playerRadius);
    camera.position.x = result.x;
    camera.position.z = result.z;
  } else {
    camera.position.x = newX;
    camera.position.z = newZ;
  }
}

// ── Jump / Vertical Physics ────────────────────────────────
function updateJump(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  if (keys.space && isGrounded && stance === 'standing') {
    velocityY = CONFIG.jumpForce;
    isGrounded = false;
    isSprinting = false;
  }

  if (!isGrounded) {
    velocityY += CONFIG.gravity * dt;
    camera.position.y += velocityY * dt;
  }

  if (camera.position.y <= CONFIG.groundLevel) {
    camera.position.y = CONFIG.groundLevel;
    velocityY = 0;
    isGrounded = true;
  }

  if (jumpIndicator) {
    jumpIndicator.textContent = isGrounded ? 'GROUNDED' : 'AIRBORNE';
    jumpIndicator.className = isGrounded ? 'grounded' : 'airborne';
  }
}

// ── Render Loop ─────────────────────────────────────────────
function animate() {
  requestAnimationFrame(animate);
  const deltaTime = clock.getDelta();

  updateCrouch(deltaTime);
  updateSprint(deltaTime);
  updateMovement(deltaTime);
  updateJump(deltaTime);
  updateCrosshair();
  updateDebugInfo(deltaTime);

  renderer.render(scene, camera);
}

// ── Debug Info ──────────────────────────────────────────────
function updateDebugInfo(deltaTime) {
  if (!debugInfo) return;

  const fps = deltaTime > 0 ? (1 / deltaTime).toFixed(0) : '—';
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z).toFixed(1);

  const keysPressed = [];
  if (keys.w) keysPressed.push('W');
  if (keys.a) keysPressed.push('A');
  if (keys.s) keysPressed.push('S');
  if (keys.d) keysPressed.push('D');
  if (keys.space) keysPressed.push('SPACE');
  if (keys.shift) keysPressed.push('SHIFT');
  if (keys.c) keysPressed.push('C');
  if (keys.control) keysPressed.push('CTRL');

  let stanceLabel;
  switch (stance) {
    case 'standing':  stanceLabel = isSprinting ? 'SPRINTING' : isExhausted ? 'EXHAUSTED' : 'STANDING'; break;
    case 'crouching': stanceLabel = 'CROUCHING'; break;
    case 'crawling':  stanceLabel = 'CRAWLING';  break;
  }

  let speedLabel;
  switch (stance) {
    case 'crawling':  speedLabel = 'CRAW';  break;
    case 'crouching': speedLabel = 'CROUCH'; break;
    default:          speedLabel = isSprinting ? 'SPRINT' : 'WALK'; break;
  }

  const yawDeg = ((yaw * 180 / Math.PI) % 360).toFixed(0);
  const pitchDeg = (pitch * 180 / Math.PI).toFixed(0);

  debugInfo.innerHTML =
    `TAHAP 08 — Arena Map<br>` +
    `FPS: ${fps} | Speed: ${speed} u/s [${speedLabel}]<br>` +
    `Pos: (${camera.position.x.toFixed(1)}, ${camera.position.y.toFixed(1)}, ${camera.position.z.toFixed(1)})<br>` +
    `Yaw: ${yawDeg}° | Pitch: ${pitchDeg}°<br>` +
    `Stance: ${stanceLabel} | ${isGrounded ? 'GROUNDED' : 'AIRBORNE'}<br>` +
    `Walls: ${collidableBoxes.length} | Stamina: ${Math.round(stamina)}%<br>` +
    `Keys: ${keysPressed.length > 0 ? keysPressed.join('+') : '—'}`;
}

// ── Entry Point ─────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
