# FPS Game 3D — Berbasis Web

Game FPS 3D berbasis web menggunakan Three.js. Dibangun secara bertahap sesuai dekomposisi.

## Tahap Saat Ini: 03 — Mekanik Lompat (Jump)

### Fitur yang sudah diimplementasi:
- **Tahap 01**: Fondasi proyek & Scene 3D (Three.js, camera, renderer, ground plane)
- **Tahap 02**: Kontrol pemain berjalan (WASD) + Pointer Lock + Mouse Look
- **Tahap 03**: Mekanik lompat (Jump) dengan fisika gravity

### Kontrol:
| Tombol | Fungsi |
|--------|--------|
| W | Maju |
| A | Kiri |
| S | Mundur |
| D | Kanan |
| Space | Lompat |
| Mouse | Lihat sekeliling |
| ESC | Lepas kursor |

### Cara Menjalankan:
1. Buka `index.html` di browser (Chrome/Firefox/Edge)
2. Klik layar untuk mengunci mouse
3. Gunakan WASD untuk berjalan, Space untuk lompat

### Teknologi:
- [Three.js](https://threejs.org/) v0.160.0 (via CDN)
- HTML5 + CSS3 + Vanilla JavaScript
- Pointer Lock API
