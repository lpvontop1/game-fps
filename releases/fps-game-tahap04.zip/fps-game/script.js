/* ============================================================
   script.js — FPS Game Tahap 04: Mekanik Lari (Sprint)
   Tahap 01-03 + Sprint (Shift) + Stamina system
   ============================================================ */

// ── Konfigurasi ──────────────────────────────────────────────
const CONFIG = {
  // Camera
  cameraFOV: 75,
  cameraNear: 0.1,
  cameraFar: 1000,
  cameraStartY: 1.7,
  cameraStartZ: 5,

  // Scene
  backgroundColor: 0xcccccc,
  groundWidth: 200,
  groundHeight: 200,
  groundColor: 0x555555,

  // Renderer
  antialias: true,

  // Grid
  showGrid: true,
  gridSize: 200,
  gridDivisions: 200,
  gridColor1: 0x444444,
  gridColor2: 0x888888,

  // ── Tahap 02: Movement ────────────────────────────────────
  walkSpeed: 5.0,
  playerHeight: 1.7,
  movementSmoothing: 0.85,

  // ── Tahap 02: Mouse Look ──────────────────────────────────
  mouseSensitivity: 0.002,

  // ── Tahap 03: Jump Physics ────────────────────────────────
  gravity: -9.8,
  jumpForce: 5.0,
  groundLevel: 1.7,

  // ── Tahap 04: Sprint & Stamina ────────────────────────────
  sprintSpeed: 9.0,            // 9 unit/s (vs walk 5 unit/s)
  staminaMax: 100,             // stamina maksimum
  staminaDrain: 20,            // stamina berkurang 20/s saat sprint
  staminaRecovery: 10,         // stamina pulih 10/s saat tidak sprint
  // Exhaustion cooldown: setelah stamina = 0, tunggu 1.5s sebelum bisa sprint lagi
  // Ini mencegah flickering (stamina recovery lalu langsung ter-drain lagi)
};

// ── Variabel Global ─────────────────────────────────────────
let scene, camera, renderer;
let clock;

// ── Input State ─────────────────────────────────────────────
const keys = {
  w: false,
  a: false,
  s: false,
  d: false,
  space: false,
  shift: false,   // Tahap 04: tombol sprint (Shift kiri)
};

// Velocity untuk movement horizontal
const velocity = new THREE.Vector3(0, 0, 0);

// ── Jump State (Tahap 03) ───────────────────────────────────
let velocityY = 0;
let isGrounded = true;

// ── Sprint & Stamina State (Tahap 04) ──────────────────────
let stamina = CONFIG.staminaMax;    // stamina saat ini
let isSprinting = false;            // apakah pemain sedang sprint
let isExhausted = false;            // Tahap 04 fix: exhaustion cooldown
let exhaustionTimer = 0;           // cooldown timer setelah stamina = 0
const EXHAUSTION_COOLDOWN = 1.5;    // 1.5 detik cooldown setelah kehabisan stamina

// Euler untuk rotasi kamera
let yaw = 0;
let pitch = 0;
const PITCH_LIMIT = Math.PI / 2 - 0.01;

// Pointer Lock state
let isPointerLocked = false;

// ── DOM Elements ────────────────────────────────────────────
const debugInfo = document.getElementById('debug-info');
const loadingScreen = document.getElementById('loading-screen');
const lockPrompt = document.getElementById('lock-prompt');
const jumpIndicator = document.getElementById('jump-indicator');
const staminaBar = document.getElementById('stamina-bar');
const staminaFill = document.getElementById('stamina-fill');
const staminaText = document.getElementById('stamina-text');

// ── Input Handling ──────────────────────────────────────────
function setupInputHandlers() {
  window.addEventListener('keydown', (e) => {
    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = true;
      e.preventDefault();
    } else if (key === 'shift') {
      keys.shift = true;
      e.preventDefault();
    } else if (key in keys) {
      keys[key] = true;
      e.preventDefault();
    }
  });

  window.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = false;
    } else if (key === 'shift') {
      keys.shift = false;
    } else if (key in keys) {
      keys[key] = false;
    }
  });

  window.addEventListener('blur', () => {
    keys.w = false;
    keys.a = false;
    keys.s = false;
    keys.d = false;
    keys.space = false;
    keys.shift = false;
  });

  // ── Pointer Lock ─────────────────────────────────────────
  const canvas = renderer.domElement;

  function requestLock() {
    if (!isPointerLocked) {
      canvas.requestPointerLock();
    }
  }

  canvas.addEventListener('click', requestLock);
  if (lockPrompt) {
    lockPrompt.addEventListener('click', requestLock);
  }

  document.addEventListener('pointerlockchange', () => {
    isPointerLocked = document.pointerLockElement === canvas;
    if (isPointerLocked) {
      if (lockPrompt) lockPrompt.style.display = 'none';
    } else {
      if (lockPrompt) lockPrompt.style.display = 'flex';
      // Reset sprint saat kehilangan pointer lock
      keys.shift = false;
    }
  });

  // ── Mouse movement ───────────────────────────────────────
  document.addEventListener('mousemove', (e) => {
    if (!isPointerLocked) return;

    const movementX = e.movementX || 0;
    const movementY = e.movementY || 0;

    yaw -= movementX * CONFIG.mouseSensitivity;
    pitch -= movementY * CONFIG.mouseSensitivity;
    pitch = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitch));

    camera.rotation.order = 'YXZ';
    camera.rotation.set(pitch, yaw, 0);
  });
}

// ── Inisialisasi ────────────────────────────────────────────
function init() {
  clock = new THREE.Clock();

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(CONFIG.backgroundColor);
  scene.fog = new THREE.Fog(CONFIG.backgroundColor, 50, 150);

  // Camera
  camera = new THREE.PerspectiveCamera(
    CONFIG.cameraFOV,
    window.innerWidth / window.innerHeight,
    CONFIG.cameraNear,
    CONFIG.cameraFar
  );
  camera.position.set(0, CONFIG.cameraStartY, CONFIG.cameraStartZ);
  camera.rotation.order = 'YXZ';
  camera.lookAt(0, CONFIG.cameraStartY, 0);
  yaw = 0;
  pitch = 0;

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: CONFIG.antialias });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // ── Ground Plane ─────────────────────────────────────────
  const groundGeometry = new THREE.PlaneGeometry(CONFIG.groundWidth, CONFIG.groundHeight);
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: CONFIG.groundColor,
    side: THREE.DoubleSide,
    roughness: 0.9,
    metalness: 0.1,
  });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  ground.name = 'ground';
  scene.add(ground);

  // ── Grid Helper ──────────────────────────────────────────
  if (CONFIG.showGrid) {
    const grid = new THREE.GridHelper(
      CONFIG.gridSize, CONFIG.gridDivisions,
      CONFIG.gridColor1, CONFIG.gridColor2
    );
    grid.position.y = 0.01;
    grid.name = 'grid';
    scene.add(grid);
  }

  // ── Reference Objects ────────────────────────────────────
  addReferenceObjects();

  // ── Lights ───────────────────────────────────────────────
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(50, 100, 50);
  scene.add(dirLight);

  // ── Setup Input ──────────────────────────────────────────
  setupInputHandlers();

  // ── Resize Handler ───────────────────────────────────────
  window.addEventListener('resize', onWindowResize);

  // ── Sembunyikan Loading Screen ───────────────────────────
  if (loadingScreen) {
    loadingScreen.classList.add('hidden');
    setTimeout(() => {
      if (loadingScreen && loadingScreen.parentNode) {
        loadingScreen.parentNode.removeChild(loadingScreen);
      }
    }, 600);
  }

  if (lockPrompt) lockPrompt.style.display = 'flex';

  // ── Mulai Render Loop ────────────────────────────────────
  animate();
}

// ── Reference Objects ───────────────────────────────────────
function addReferenceObjects() {
  const boxGeometry = new THREE.BoxGeometry(2, 2, 2);
  const colors = [0xff4444, 0x44ff44, 0x4444ff, 0xffff44, 0xff44ff, 0x44ffff];
  const positions = [
    [8, 1, -10], [-8, 1, -10], [0, 1, -20],
    [12, 1, -5], [-12, 1, -5], [0, 1, 5],
  ];
  positions.forEach((pos, i) => {
    const mat = new THREE.MeshStandardMaterial({ color: colors[i], roughness: 0.5, metalness: 0.2 });
    const box = new THREE.Mesh(boxGeometry, mat);
    box.position.set(pos[0], pos[1], pos[2]);
    box.name = 'refBox_' + i;
    scene.add(box);
  });

  const pillarGeo = new THREE.CylinderGeometry(0.5, 0.5, 4, 8);
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7 });
  const pillarPositions = [
    [20, 2, -30], [-20, 2, -30], [20, 2, 20], [-20, 2, 20],
    [0, 2, -40], [30, 2, -10], [-30, 2, -10],
  ];
  pillarPositions.forEach((pos, i) => {
    const pillar = new THREE.Mesh(pillarGeo, pillarMat);
    pillar.position.set(pos[0], pos[1], pos[2]);
    pillar.name = 'pillar_' + i;
    scene.add(pillar);
  });
}

// ── Resize Handler ──────────────────────────────────────────
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ── Tahap 04: Update Sprint & Stamina ──────────────────────
function updateSprint(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  // Apakah pemain menekan tombol gerak?
  const isMoving = keys.w || keys.a || keys.s || keys.d;

  // ── Exhaustion cooldown ──────────────────────────────────
  // Jika pemain kehabisan stamina, tunggu cooldown sebelum bisa sprint lagi
  if (isExhausted) {
    exhaustionTimer -= dt;
    if (exhaustionTimer <= 0) {
      isExhausted = false;
      exhaustionTimer = 0;
    }
  }

  // Sprint hanya bisa jika:
  // - Shift ditekan
  // - Pemain di ground (tidak bisa sprint di udara)
  // - Stamina > 0
  // - Pemain bergerak (WASD ditekan)
  // - Tidak dalam exhaustion cooldown
  const canSprint = keys.shift && isGrounded && stamina > 0 && isMoving && !isExhausted;

  if (canSprint) {
    isSprinting = true;
    stamina -= CONFIG.staminaDrain * dt;

    // Stamina habis → masuk exhaustion
    if (stamina <= 0) {
      stamina = 0;
      isExhausted = true;
      exhaustionTimer = EXHAUSTION_COOLDOWN;
    }
  } else {
    isSprinting = false;

    // Stamina recovery: pulih saat TIDAK sprint
    // Recovery juga saat pemain berdiri diam (tidak menekan WASD)
    stamina += CONFIG.staminaRecovery * dt;

    // Stamina tidak boleh melebihi max
    if (stamina > CONFIG.staminaMax) stamina = CONFIG.staminaMax;
  }

  // ── Update stamina bar HUD ───────────────────────────────
  if (staminaFill) {
    const pct = (stamina / CONFIG.staminaMax) * 100;
    staminaFill.style.width = pct + '%';

    // Warna berubah berdasarkan level stamina
    if (pct > 60) {
      staminaFill.style.background = '#00ff00';      // hijau
    } else if (pct > 30) {
      staminaFill.style.background = '#ffaa00';      // kuning
    } else {
      staminaFill.style.background = '#ff3300';      // merah
    }
  }

  if (staminaText) {
    staminaText.textContent = Math.round(stamina) + '%';
  }

  // Visual: flash stamina bar saat stamina habis
  if (staminaBar) {
    if (stamina <= 0 && keys.shift) {
      staminaBar.classList.add('exhausted');
    } else {
      staminaBar.classList.remove('exhausted');
    }
  }
}

// ── Tahap 02+04: Update Horizontal Movement ────────────────
function updateMovement(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  // ── Tentukan kecepatan saat ini ──────────────────────────
  // Sprint: 9 u/s (hanya jika isSprinting)
  // Walk: 5 u/s (default)
  const currentSpeed = isSprinting ? CONFIG.sprintSpeed : CONFIG.walkSpeed;

  // Hitung arah forward dan right dari camera
  const cameraDirection = new THREE.Vector3();
  camera.getWorldDirection(cameraDirection);

  const forwardXZ = new THREE.Vector3(cameraDirection.x, 0, cameraDirection.z);
  const forwardLen = forwardXZ.length();

  let forward, right;
  if (forwardLen > 0.001) {
    forward = forwardXZ.normalize();
    right = new THREE.Vector3();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  } else {
    forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  }

  // Target velocity dari input
  const targetVelocity = new THREE.Vector3(0, 0, 0);
  if (keys.w) targetVelocity.add(forward);
  if (keys.s) targetVelocity.sub(forward);
  if (keys.d) targetVelocity.add(right);
  if (keys.a) targetVelocity.sub(right);

  if (targetVelocity.lengthSq() > 0) {
    targetVelocity.normalize();
  }
  targetVelocity.multiplyScalar(currentSpeed);

  // Velocity-based smoothing
  const smoothing = CONFIG.movementSmoothing;
  const lerpFactor = 1 - Math.pow(smoothing, dt * 60);

  velocity.x += (targetVelocity.x - velocity.x) * lerpFactor;
  velocity.z += (targetVelocity.z - velocity.z) * lerpFactor;

  // Update posisi horizontal
  camera.position.x += velocity.x * dt;
  camera.position.z += velocity.z * dt;
}

// ── Tahap 03: Update Jump / Vertical Physics ───────────────
function updateJump(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  // Lompat: hanya bisa saat di ground
  if (keys.space && isGrounded) {
    velocityY = CONFIG.jumpForce;
    isGrounded = false;

    // Saat lompat, sprint otomatis berhenti (pemain tidak di ground)
    isSprinting = false;
  }

  // Fisika: terapkan gravity setiap frame
  if (!isGrounded) {
    velocityY += CONFIG.gravity * dt;
    camera.position.y += velocityY * dt;
  }

  // Ground check
  if (camera.position.y <= CONFIG.groundLevel) {
    camera.position.y = CONFIG.groundLevel;
    velocityY = 0;
    isGrounded = true;
  }

  // Update jump indicator HUD
  if (jumpIndicator) {
    if (isGrounded) {
      jumpIndicator.textContent = 'GROUNDED';
      jumpIndicator.className = 'grounded';
    } else {
      jumpIndicator.textContent = 'AIRBORNE';
      jumpIndicator.className = 'airborne';
    }
  }
}

// ── Render Loop ─────────────────────────────────────────────
function animate() {
  requestAnimationFrame(animate);

  const deltaTime = clock.getDelta();

  updateSprint(deltaTime);     // Tahap 04: update stamina sebelum movement
  updateMovement(deltaTime);   // Tahap 02+04: movement dengan speed yang sesuai
  updateJump(deltaTime);       // Tahap 03: jump physics
  updateDebugInfo(deltaTime);

  renderer.render(scene, camera);
}

// ── Debug Info ──────────────────────────────────────────────
function updateDebugInfo(deltaTime) {
  if (!debugInfo) return;

  const fps = deltaTime > 0 ? (1 / deltaTime).toFixed(0) : '—';
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z).toFixed(1);

  const keysPressed = [];
  if (keys.w) keysPressed.push('W');
  if (keys.a) keysPressed.push('A');
  if (keys.s) keysPressed.push('S');
  if (keys.d) keysPressed.push('D');
  if (keys.space) keysPressed.push('SPACE');
  if (keys.shift) keysPressed.push('SHIFT');

  const yawDeg = ((yaw * 180 / Math.PI) % 360).toFixed(0);
  const pitchDeg = (pitch * 180 / Math.PI).toFixed(0);

  debugInfo.innerHTML =
    `TAHAP 04 — Mekanik Lari (Sprint)<br>` +
    `FPS: ${fps} | Speed: ${speed} u/s<br>` +
    `Pos: (${camera.position.x.toFixed(1)}, ${camera.position.y.toFixed(1)}, ${camera.position.z.toFixed(1)})<br>` +
    `VelY: ${velocityY.toFixed(2)} | ${isGrounded ? 'GROUNDED' : 'AIRBORNE'}<br>` +
    `Stamina: ${Math.round(stamina)} | ${isSprinting ? 'SPRINTING' : isExhausted ? 'EXHAUSTED' : 'WALKING'}<br>` +
    `Keys: ${keysPressed.length > 0 ? keysPressed.join('+') : '—'}`;
}

// ── Entry Point ─────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
