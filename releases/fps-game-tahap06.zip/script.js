/* ============================================================
   script.js — FPS Game Tahap 06: Mouse Look / Kamera FPS Pertama
   Tahap 01-05 + FIX: Browser shortcut blocker + Mouse smoothing
   + Adjustable sensitivity + Enhanced dynamic crosshair
   ============================================================ */

// ── Konfigurasi ──────────────────────────────────────────────
const CONFIG = {
  // Camera
  cameraFOV: 75,
  cameraNear: 0.1,
  cameraFar: 1000,
  cameraStartY: 1.7,
  cameraStartZ: 5,

  // Scene
  backgroundColor: 0xcccccc,
  groundWidth: 200,
  groundHeight: 200,
  groundColor: 0x555555,

  // Renderer
  antialias: true,

  // Grid
  showGrid: true,
  gridSize: 200,
  gridDivisions: 200,
  gridColor1: 0x444444,
  gridColor2: 0x888888,

  // ── Tahap 02: Movement ────────────────────────────────────
  walkSpeed: 5.0,
  playerHeight: 1.7,
  movementSmoothing: 0.85,

  // ── Tahap 06: Mouse Look ──────────────────────────────────
  mouseSensitivity: 0.002,           // default sensitivity (radian per pixel)
  mouseSensitivityMin: 0.0005,       // minimum sensitivity
  mouseSensitivityMax: 0.01,         // maximum sensitivity
  mouseSensitivityStep: 0.0005,      // step per key press (+/-)
  mouseSmoothing: 0.6,              // mouse input smoothing (0=raw, 1=max smooth)
  // Smoothing: kita simpan buffer beberapa frame dan average
  mouseSmoothBuffer: 4,             // jumlah frame untuk smoothing buffer

  // ── Tahap 03: Jump Physics ────────────────────────────────
  gravity: -9.8,
  jumpForce: 5.0,
  groundLevel: 1.7,

  // ── Tahap 04: Sprint & Stamina ────────────────────────────
  sprintSpeed: 9.0,            // 9 unit/s (vs walk 5 unit/s)
  staminaMax: 100,             // stamina maksimum
  staminaDrain: 20,            // stamina berkurang 20/s saat sprint
  staminaRecovery: 10,         // stamina pulih 10/s saat tidak sprint

  // ── Tahap 05: Crouch & Crawl ──────────────────────────────
  crouchSpeed: 3.0,            // 3 unit/s saat jongkok
  crawlSpeed: 2.0,             // 2 unit/s saat merayap
  crouchHeight: 0.9,           // tinggi kamera saat crouch (y=0.9)
  crawlHeight: 0.4,            // tinggi kamera saat crawl (y=0.4)
  standHeight: 1.7,            // tinggi kamera saat berdiri (y=1.7)
  crouchTransitionLerp: 0.12,  // lerp factor untuk smooth transisi kamera Y
};

// ── Variabel Global ─────────────────────────────────────────
let scene, camera, renderer;
let clock;

// ── Input State ─────────────────────────────────────────────
const keys = {
  w: false,
  a: false,
  s: false,
  d: false,
  space: false,
  shift: false,   // Tahap 04: tombol sprint (Shift kiri)
  c: false,        // Tahap 05: tombol crouch toggle (C)
  control: false,  // Tahap 05: tombol crawl (Ctrl)
};

// Velocity untuk movement horizontal
const velocity = new THREE.Vector3(0, 0, 0);

// ── Jump State (Tahap 03) ───────────────────────────────────
let velocityY = 0;
let isGrounded = true;

// ── Sprint & Stamina State (Tahap 04) ──────────────────────
let stamina = CONFIG.staminaMax;    // stamina saat ini
let isSprinting = false;            // apakah pemain sedang sprint
let isExhausted = false;            // exhaustion cooldown
let exhaustionTimer = 0;           // cooldown timer setelah stamina = 0
const EXHAUSTION_COOLDOWN = 1.5;    // 1.5 detik cooldown setelah kehabisan stamina

// ── Crouch & Crawl State (Tahap 05) ────────────────────────
// Stance: 'standing', 'crouching', 'crawling'
let stance = 'standing';
let targetCameraY = CONFIG.standHeight;   // target tinggi kamera (untuk lerp)
let crouchJustPressed = false;            // flag: C baru ditekan (untuk toggle logic)

// ── Mouse Look State (Tahap 06) ────────────────────────────
let yaw = 0;
let pitch = 0;
const PITCH_LIMIT = Math.PI / 2 - 0.01;

// Mouse smoothing buffer — menyimpan N frame terakhir
let mouseBufferX = [];
let mouseBufferY = [];

// Dynamic sensitivity (bisa diubah runtime)
let mouseSensitivity = CONFIG.mouseSensitivity;

// Pointer Lock state
let isPointerLocked = false;

// ── DOM Elements ────────────────────────────────────────────
const debugInfo = document.getElementById('debug-info');
const loadingScreen = document.getElementById('loading-screen');
const lockPrompt = document.getElementById('lock-prompt');
const jumpIndicator = document.getElementById('jump-indicator');
const staminaBar = document.getElementById('stamina-bar');
const staminaFill = document.getElementById('stamina-fill');
const staminaText = document.getElementById('stamina-text');
const crouchIndicator = document.getElementById('crouch-indicator');
const crosshair = document.getElementById('crosshair');
const sensitivityIndicator = document.getElementById('sensitivity-indicator');

// ── Input Handling ──────────────────────────────────────────
function setupInputHandlers() {
  window.addEventListener('keydown', (e) => {
    // ── FIX Tahap 05/06: Blokir semua browser shortcuts saat pointer lock ──
    // Saat game aktif (pointer locked), semua key combination harus di-prevent
    // agar tidak memicu browser shortcut (Ctrl+W tutup tab, Ctrl+R reload, dll)
    if (isPointerLocked) {
      e.preventDefault();
      e.stopPropagation();
    }

    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = true;
    } else if (key === 'shift') {
      keys.shift = true;
    } else if (key === 'control') {
      keys.control = true;
    } else if (key === 'c') {
      // ── Tahap 05: C toggle untuk crouch/crawl ────────────
      // C adalah toggle, jadi hanya merespons keydown (bukan hold)
      if (!keys.c) {
        crouchJustPressed = true;
      }
      keys.c = true;
    } else if (key in keys) {
      keys[key] = true;
    }

    // ── Tahap 06: Adjustable sensitivity (+/- keys) ────────
    if (isPointerLocked) {
      if (key === '=' || key === '+' || key === 'numpadadd') {
        // Increase sensitivity
        mouseSensitivity = Math.min(
          CONFIG.mouseSensitivityMax,
          mouseSensitivity + CONFIG.mouseSensitivityStep
        );
        showSensitivityIndicator();
      } else if (key === '-' || key === 'numpadsubtract') {
        // Decrease sensitivity
        mouseSensitivity = Math.max(
          CONFIG.mouseSensitivityMin,
          mouseSensitivity - CONFIG.mouseSensitivityStep
        );
        showSensitivityIndicator();
      }
    }
  }, true);  // capture phase = true, agar kita intercept sebelum browser

  window.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = false;
    } else if (key === 'shift') {
      keys.shift = false;
    } else if (key === 'control') {
      keys.control = false;
    } else if (key === 'c') {
      keys.c = false;
    } else if (key in keys) {
      keys[key] = false;
    }
  });

  window.addEventListener('blur', () => {
    keys.w = false;
    keys.a = false;
    keys.s = false;
    keys.d = false;
    keys.space = false;
    keys.shift = false;
    keys.c = false;
    keys.control = false;
  });

  // ── Pointer Lock ─────────────────────────────────────────
  const canvas = renderer.domElement;

  function requestLock() {
    if (!isPointerLocked) {
      canvas.requestPointerLock();
    }
  }

  canvas.addEventListener('click', requestLock);
  if (lockPrompt) {
    lockPrompt.addEventListener('click', requestLock);
  }

  document.addEventListener('pointerlockchange', () => {
    isPointerLocked = document.pointerLockElement === canvas;
    if (isPointerLocked) {
      if (lockPrompt) lockPrompt.style.display = 'none';
    } else {
      if (lockPrompt) lockPrompt.style.display = 'flex';
      // Reset keys saat kehilangan pointer lock
      keys.shift = false;
      keys.c = false;
      keys.control = false;
      // Jika sedang crouch/crawl, kembalikan ke standing saat unlock
      if (stance !== 'standing') {
        stance = 'standing';
        targetCameraY = CONFIG.standHeight;
      }
    }
  });

  // ── Mouse movement with smoothing (Tahap 06) ────────────
  document.addEventListener('mousemove', (e) => {
    if (!isPointerLocked) return;

    const rawX = e.movementX || 0;
    const rawY = e.movementY || 0;

    // Tambah ke smoothing buffer
    mouseBufferX.push(rawX);
    mouseBufferY.push(rawY);

    // Trim buffer ke ukuran maksimum
    while (mouseBufferX.length > CONFIG.mouseSmoothBuffer) {
      mouseBufferX.shift();
      mouseBufferY.shift();
    }

    // Average buffer untuk smoothing
    const smoothX = mouseBufferX.reduce((a, b) => a + b, 0) / mouseBufferX.length;
    const smoothY = mouseBufferY.reduce((a, b) => a + b, 0) / mouseBufferY.length;

    // Blend antara raw dan smoothed berdasarkan CONFIG.mouseSmoothing
    // smoothing=0 → fully raw, smoothing=1 → fully smoothed
    const sm = CONFIG.mouseSmoothing;
    const finalX = rawX * (1 - sm) + smoothX * sm;
    const finalY = rawY * (1 - sm) + smoothY * sm;

    // Apply sensitivity dan update yaw/pitch
    yaw -= finalX * mouseSensitivity;
    pitch -= finalY * mouseSensitivity;
    pitch = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitch));

    camera.rotation.order = 'YXZ';
    camera.rotation.set(pitch, yaw, 0);
  });
}

// ── Tahap 06: Show Sensitivity Indicator (fade out) ────────
let sensitivityTimeout = null;
function showSensitivityIndicator() {
  if (sensitivityIndicator) {
    const pct = ((mouseSensitivity - CONFIG.mouseSensitivityMin) /
                 (CONFIG.mouseSensitivityMax - CONFIG.mouseSensitivityMin) * 100);
    sensitivityIndicator.textContent = `SENS: ${mouseSensitivity.toFixed(4)} (${Math.round(pct)}%)`;
    sensitivityIndicator.style.opacity = '1';
    sensitivityIndicator.style.display = 'block';

    if (sensitivityTimeout) clearTimeout(sensitivityTimeout);
    sensitivityTimeout = setTimeout(() => {
      if (sensitivityIndicator) {
        sensitivityIndicator.style.opacity = '0';
        setTimeout(() => {
          if (sensitivityIndicator) sensitivityIndicator.style.display = 'none';
        }, 400);
      }
    }, 2000);
  }
}

// ── Tahap 06: Update Dynamic Crosshair ─────────────────────
function updateCrosshair() {
  if (!crosshair) return;

  const isMoving = keys.w || keys.a || keys.s || keys.d;
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);

  // Dynamic crosshair: expand saat bergerak/sprint, contract saat diam
  let spread = 0; // base spread in pixels
  if (isSprinting) {
    spread = 8;
  } else if (speed > 2) {
    spread = 4;
  } else if (isMoving) {
    spread = 2;
  }

  // Extra spread saat crouching/crawling → crosshair lebih kecil (akurat)
  if (stance === 'crouching') spread = Math.max(0, spread - 2);
  if (stance === 'crawling') spread = 0;

  // Apply spread via CSS custom property
  crosshair.style.setProperty('--spread', spread + 'px');

  // Color: putih saat standing, kuning saat sprint, hijau saat crouch/crawl
  if (stance === 'crawling') {
    crosshair.style.setProperty('--ch-color', 'rgba(0, 255, 100, 0.9)');
  } else if (stance === 'crouching') {
    crosshair.style.setProperty('--ch-color', 'rgba(100, 255, 100, 0.9)');
  } else if (isSprinting) {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 200, 50, 0.9)');
  } else {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 255, 255, 0.8)');
  }
}

// ── Inisialisasi ────────────────────────────────────────────
function init() {
  clock = new THREE.Clock();

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(CONFIG.backgroundColor);
  scene.fog = new THREE.Fog(CONFIG.backgroundColor, 50, 150);

  // Camera
  camera = new THREE.PerspectiveCamera(
    CONFIG.cameraFOV,
    window.innerWidth / window.innerHeight,
    CONFIG.cameraNear,
    CONFIG.cameraFar
  );
  camera.position.set(0, CONFIG.cameraStartY, CONFIG.cameraStartZ);
  camera.rotation.order = 'YXZ';
  camera.lookAt(0, CONFIG.cameraStartY, 0);
  yaw = 0;
  pitch = 0;

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: CONFIG.antialias });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // ── Ground Plane ─────────────────────────────────────────
  const groundGeometry = new THREE.PlaneGeometry(CONFIG.groundWidth, CONFIG.groundHeight);
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: CONFIG.groundColor,
    side: THREE.DoubleSide,
    roughness: 0.9,
    metalness: 0.1,
  });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  ground.name = 'ground';
  scene.add(ground);

  // ── Grid Helper ──────────────────────────────────────────
  if (CONFIG.showGrid) {
    const grid = new THREE.GridHelper(
      CONFIG.gridSize, CONFIG.gridDivisions,
      CONFIG.gridColor1, CONFIG.gridColor2
    );
    grid.position.y = 0.01;
    grid.name = 'grid';
    scene.add(grid);
  }

  // ── Reference Objects ────────────────────────────────────
  addReferenceObjects();

  // ── Lights ───────────────────────────────────────────────
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(50, 100, 50);
  scene.add(dirLight);

  // ── Setup Input ──────────────────────────────────────────
  setupInputHandlers();

  // ── Resize Handler ───────────────────────────────────────
  window.addEventListener('resize', onWindowResize);

  // ── Sembunyikan Loading Screen ───────────────────────────
  if (loadingScreen) {
    loadingScreen.classList.add('hidden');
    setTimeout(() => {
      if (loadingScreen && loadingScreen.parentNode) {
        loadingScreen.parentNode.removeChild(loadingScreen);
      }
    }, 600);
  }

  if (lockPrompt) lockPrompt.style.display = 'flex';

  // ── Mulai Render Loop ────────────────────────────────────
  animate();
}

// ── Reference Objects ───────────────────────────────────────
function addReferenceObjects() {
  const boxGeometry = new THREE.BoxGeometry(2, 2, 2);
  const colors = [0xff4444, 0x44ff44, 0x4444ff, 0xffff44, 0xff44ff, 0x44ffff];
  const positions = [
    [8, 1, -10], [-8, 1, -10], [0, 1, -20],
    [12, 1, -5], [-12, 1, -5], [0, 1, 5],
  ];
  positions.forEach((pos, i) => {
    const mat = new THREE.MeshStandardMaterial({ color: colors[i], roughness: 0.5, metalness: 0.2 });
    const box = new THREE.Mesh(boxGeometry, mat);
    box.position.set(pos[0], pos[1], pos[2]);
    box.name = 'refBox_' + i;
    scene.add(box);
  });

  const pillarGeo = new THREE.CylinderGeometry(0.5, 0.5, 4, 8);
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7 });
  const pillarPositions = [
    [20, 2, -30], [-20, 2, -30], [20, 2, 20], [-20, 2, 20],
    [0, 2, -40], [30, 2, -10], [-30, 2, -10],
  ];
  pillarPositions.forEach((pos, i) => {
    const pillar = new THREE.Mesh(pillarGeo, pillarMat);
    pillar.position.set(pos[0], pos[1], pos[2]);
    pillar.name = 'pillar_' + i;
    scene.add(pillar);
  });
}

// ── Resize Handler ──────────────────────────────────────────
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ── Tahap 05: Update Crouch / Crawl ────────────────────────
function updateCrouch(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  // ── Toggle logic: C ditekan ──────────────────────────────
  // State machine: standing → crouching → crawling → standing
  if (crouchJustPressed) {
    crouchJustPressed = false;

    switch (stance) {
      case 'standing':
        stance = 'crouching';
        targetCameraY = CONFIG.crouchHeight;
        break;
      case 'crouching':
        stance = 'crawling';
        targetCameraY = CONFIG.crawlHeight;
        break;
      case 'crawling':
        stance = 'standing';
        targetCameraY = CONFIG.standHeight;
        break;
    }
  }

  // ── Ctrl sebagai shortcut untuk langsung crawl ───────────
  if (keys.control && stance !== 'crawling') {
    stance = 'crawling';
    targetCameraY = CONFIG.crawlHeight;
  }

  // ── Smooth transisi kamera Y dengan framerate-independent lerp ─
  if (isGrounded) {
    const currentY = camera.position.y;
    const lerpFactor = 1 - Math.pow(1 - CONFIG.crouchTransitionLerp, dt * 60);
    const newY = currentY + (targetCameraY - currentY) * lerpFactor;
    camera.position.y = newY;

    if (Math.abs(camera.position.y - targetCameraY) < 0.01) {
      camera.position.y = targetCameraY;
    }

    CONFIG.groundLevel = targetCameraY;
  }

  // ── Update crouch indicator HUD ──────────────────────────
  if (crouchIndicator) {
    switch (stance) {
      case 'standing':
        crouchIndicator.textContent = 'STANDING';
        crouchIndicator.className = 'standing';
        break;
      case 'crouching':
        crouchIndicator.textContent = 'CROUCHING';
        crouchIndicator.className = 'crouching';
        break;
      case 'crawling':
        crouchIndicator.textContent = 'CRAWLING';
        crouchIndicator.className = 'crawling';
        break;
    }
  }
}

// ── Tahap 04+05: Update Sprint & Stamina ───────────────────
function updateSprint(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  const isMoving = keys.w || keys.a || keys.s || keys.d;

  if (isExhausted) {
    exhaustionTimer -= dt;
    if (exhaustionTimer <= 0) {
      isExhausted = false;
      exhaustionTimer = 0;
    }
  }

  const canSprint = keys.shift && isGrounded && stamina > 0 && isMoving && !isExhausted && stance === 'standing';

  if (canSprint) {
    isSprinting = true;
    stamina -= CONFIG.staminaDrain * dt;

    if (stamina <= 0) {
      stamina = 0;
      isExhausted = true;
      exhaustionTimer = EXHAUSTION_COOLDOWN;
    }
  } else {
    isSprinting = false;
    stamina += CONFIG.staminaRecovery * dt;
    if (stamina > CONFIG.staminaMax) stamina = CONFIG.staminaMax;
  }

  if (staminaFill) {
    const pct = (stamina / CONFIG.staminaMax) * 100;
    staminaFill.style.width = pct + '%';

    if (pct > 60) {
      staminaFill.style.background = '#00ff00';
    } else if (pct > 30) {
      staminaFill.style.background = '#ffaa00';
    } else {
      staminaFill.style.background = '#ff3300';
    }
  }

  if (staminaText) {
    staminaText.textContent = Math.round(stamina) + '%';
  }

  if (staminaBar) {
    if (stamina <= 0 && keys.shift) {
      staminaBar.classList.add('exhausted');
    } else {
      staminaBar.classList.remove('exhausted');
    }
  }
}

// ── Tahap 02+04+05: Update Horizontal Movement ─────────────
function updateMovement(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  let currentSpeed;
  if (stance === 'crawling') {
    currentSpeed = CONFIG.crawlSpeed;
  } else if (stance === 'crouching') {
    currentSpeed = CONFIG.crouchSpeed;
  } else if (isSprinting) {
    currentSpeed = CONFIG.sprintSpeed;
  } else {
    currentSpeed = CONFIG.walkSpeed;
  }

  const cameraDirection = new THREE.Vector3();
  camera.getWorldDirection(cameraDirection);

  const forwardXZ = new THREE.Vector3(cameraDirection.x, 0, cameraDirection.z);
  const forwardLen = forwardXZ.length();

  let forward, right;
  if (forwardLen > 0.001) {
    forward = forwardXZ.normalize();
    right = new THREE.Vector3();
    right.crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  } else {
    forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  }

  const targetVelocity = new THREE.Vector3(0, 0, 0);
  if (keys.w) targetVelocity.add(forward);
  if (keys.s) targetVelocity.sub(forward);
  if (keys.d) targetVelocity.add(right);
  if (keys.a) targetVelocity.sub(right);

  if (targetVelocity.lengthSq() > 0) {
    targetVelocity.normalize();
  }
  targetVelocity.multiplyScalar(currentSpeed);

  const smoothing = CONFIG.movementSmoothing;
  const lerpFactor = 1 - Math.pow(smoothing, dt * 60);

  velocity.x += (targetVelocity.x - velocity.x) * lerpFactor;
  velocity.z += (targetVelocity.z - velocity.z) * lerpFactor;

  camera.position.x += velocity.x * dt;
  camera.position.z += velocity.z * dt;
}

// ── Tahap 03+05: Update Jump / Vertical Physics ────────────
function updateJump(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  const canJump = keys.space && isGrounded && stance === 'standing';

  if (canJump) {
    velocityY = CONFIG.jumpForce;
    isGrounded = false;
    isSprinting = false;
  }

  if (!isGrounded) {
    velocityY += CONFIG.gravity * dt;
    camera.position.y += velocityY * dt;
  }

  if (camera.position.y <= CONFIG.groundLevel) {
    camera.position.y = CONFIG.groundLevel;
    velocityY = 0;
    isGrounded = true;
  }

  if (jumpIndicator) {
    if (isGrounded) {
      jumpIndicator.textContent = 'GROUNDED';
      jumpIndicator.className = 'grounded';
    } else {
      jumpIndicator.textContent = 'AIRBORNE';
      jumpIndicator.className = 'airborne';
    }
  }
}

// ── Render Loop ─────────────────────────────────────────────
function animate() {
  requestAnimationFrame(animate);

  const deltaTime = clock.getDelta();

  updateCrouch(deltaTime);      // Tahap 05: crouch/crawl toggle & smooth transisi
  updateSprint(deltaTime);      // Tahap 04: update stamina sebelum movement
  updateMovement(deltaTime);    // Tahap 02+04+05: movement dengan speed yang sesuai
  updateJump(deltaTime);        // Tahap 03+05: jump physics
  updateCrosshair();            // Tahap 06: dynamic crosshair
  updateDebugInfo(deltaTime);

  renderer.render(scene, camera);
}

// ── Debug Info ──────────────────────────────────────────────
function updateDebugInfo(deltaTime) {
  if (!debugInfo) return;

  const fps = deltaTime > 0 ? (1 / deltaTime).toFixed(0) : '—';
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z).toFixed(1);

  const keysPressed = [];
  if (keys.w) keysPressed.push('W');
  if (keys.a) keysPressed.push('A');
  if (keys.s) keysPressed.push('S');
  if (keys.d) keysPressed.push('D');
  if (keys.space) keysPressed.push('SPACE');
  if (keys.shift) keysPressed.push('SHIFT');
  if (keys.c) keysPressed.push('C');
  if (keys.control) keysPressed.push('CTRL');

  let stanceLabel;
  switch (stance) {
    case 'standing':  stanceLabel = isSprinting ? 'SPRINTING' : isExhausted ? 'EXHAUSTED' : 'STANDING'; break;
    case 'crouching': stanceLabel = 'CROUCHING'; break;
    case 'crawling':  stanceLabel = 'CRAWLING';  break;
    default:          stanceLabel = stance.toUpperCase(); break;
  }

  let speedLabel;
  switch (stance) {
    case 'crawling':  speedLabel = 'CRAW';  break;
    case 'crouching': speedLabel = 'CROUCH'; break;
    default:          speedLabel = isSprinting ? 'SPRINT' : 'WALK'; break;
  }

  const yawDeg = ((yaw * 180 / Math.PI) % 360).toFixed(0);
  const pitchDeg = (pitch * 180 / Math.PI).toFixed(0);

  debugInfo.innerHTML =
    `TAHAP 06 — Mouse Look / Kamera FPS<br>` +
    `FPS: ${fps} | Speed: ${speed} u/s [${speedLabel}]<br>` +
    `Pos: (${camera.position.x.toFixed(1)}, ${camera.position.y.toFixed(1)}, ${camera.position.z.toFixed(1)})<br>` +
    `Yaw: ${yawDeg}° | Pitch: ${pitchDeg}°<br>` +
    `Stance: ${stanceLabel} | ${isGrounded ? 'GROUNDED' : 'AIRBORNE'}<br>` +
    `Stamina: ${Math.round(stamina)}% | Sens: ${mouseSensitivity.toFixed(4)}<br>` +
    `Keys: ${keysPressed.length > 0 ? keysPressed.join('+') : '—'}`;
}

// ── Entry Point ─────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
