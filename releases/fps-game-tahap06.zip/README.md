# FPS Game 3D — Berbasis Web

Game FPS 3D berbasis web menggunakan Three.js. Dibangun secara bertahap sesuai dekomposisi.

## Tahap Saat Ini: 06 — Mouse Look / Kamera FPS Pertama

### Fitur yang sudah diimplementasi:
- **Tahap 01**: Fondasi proyek & Scene 3D (Three.js, camera, renderer, ground plane)
- **Tahap 02**: Kontrol pemain berjalan (WASD) + Pointer Lock + Mouse Look
- **Tahap 03**: Mekanik lompat (Jump) dengan fisika gravity (-9.8 u/s²)
- **Tahap 04**: Mekanik lari (Sprint) + Stamina system + Exhaustion cooldown
- **Tahap 05**: Mekanik jongkok (Crouch) & merayap (Crawl) + Smooth camera transitions
- **Tahap 06**: Mouse Look refinement + Mouse smoothing + Adjustable sensitivity + Dynamic crosshair + Browser shortcut blocker

### Kontrol:
| Tombol | Fungsi |
|--------|--------|
| W | Maju |
| A | Kiri |
| S | Mundur |
| D | Kanan |
| Shift | Lari (Sprint) — hanya saat standing |
| C | Toggle Jongkok (Crouch) → Merayap (Crawl) → Berdiri |
| Ctrl | Merayap langsung (Crawl shortcut) |
| Space | Lompat — hanya saat standing |
| + / - | Atur sensitivitas mouse |
| Mouse | Lihat sekeliling (smooth) |
| ESC | Lepas kursor |

### Detail Mouse Look (Tahap 06):
- **Mouse smoothing**: Buffer 4-frame dengan blending (0.6 smoothing factor), menghilangkan jitter
- **Adjustable sensitivity**: +/- key, range 0.0005–0.01 rad/px, step 0.0005
- **Sensitivity indicator**: HUD muncul saat diubah, fade out setelah 2 detik
- **Dynamic crosshair**: Spread saat bergerak/sprint, contract saat crouch/crawl, warna berubah sesuai stance
- **Browser shortcut blocker**: Ctrl+W, Ctrl+R, dll. diblokir saat pointer lock aktif

### Bug Fix (Tahap 05):
- **Ctrl+W no longer closes tab**: Semua keyboard shortcut browser diblokir saat game aktif (pointer locked), menggunakan capture phase event listener dengan `e.preventDefault()`

### Detail Crouch/Crawl (Tahap 05):
- **Crouch**: y=0.9, speed=3 u/s | **Crawl**: y=0.4, speed=2 u/s
- **Smooth transition**: Framerate-independent lerp
- **Jump & Sprint blocked** saat crouching/crawling

### Detail Sprint & Stamina (Tahap 04):
- **Sprint**: 9 u/s (vs walk 5 u/s) | Stamina: max 100, drain 20/s, recovery 10/s
- **Sprint hanya saat grounded & standing** | Exhaustion cooldown: 1.5 detik

### Cara Menjalankan:
1. Buka `index.html` di browser (Chrome/Firefox/Edge)
2. Klik layar untuk mengunci mouse
3. Gunakan kontrol di atas untuk bermain

### Teknologi:
- [Three.js](https://threejs.org/) v0.160.0 (via CDN)
- HTML5 + CSS3 + Vanilla JavaScript
- Pointer Lock API

### Download:
- `fps game.zip` — Source code lengkap + Screenshot + GIF demo
