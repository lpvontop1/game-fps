# FPS Game 3D — Berbasis Web

Game FPS 3D berbasis web menggunakan Three.js. Dibangun secara bertahap sesuai dekomposisi.

## Tahap Saat Ini: 07 — Collision Detection Dasar

### Fitur yang sudah diimplementasi:
- **Tahap 01**: Fondasi proyek & Scene 3D
- **Tahap 02**: Kontrol pemain berjalan (WASD) + Pointer Lock + Mouse Look
- **Tahap 03**: Mekanik lompat (Jump) + fisika gravity
- **Tahap 04**: Mekanik lari (Sprint) + Stamina + Exhaustion cooldown
- **Tahap 05**: Mekanik jongkok/merayap (Crouch/Crawl) + Smooth transitions
- **Tahap 06**: Mouse Look refinement + Mouse smoothing + Adjustable sensitivity + Dynamic crosshair
- **Tahap 07**: Collision Detection (AABB) + Wall Slide + Bug fixes

### Bug Fixes (Tahap 07):
- **Crosshair tetap di tengah**: Diganti dari 2 pseudo-element menjadi 4 child div + dot. Crosshair melebar dari pusat (spread), TIDAK bergeser.
- **Ctrl+W benar-benar diblokir**: 3-layer defense — (1) Keyboard Lock API (`navigator.keyboard.lock()`), (2) Fullscreen mode saat bermain, (3) `beforeunload` handler + `e.stopImmediatePropagation()`.

### Detail Collision Detection (Tahap 07):
- **Implementasi**: AABB collision pada XZ plane (circle vs rectangle)
- **Player bounding**: Circle radius 0.5 pada XZ plane
- **Wall slide**: Jika collision, komponen velocity sejajar dinding dipertahankan, komponen menuju dinding dihapus
- **Obstacles**: 3 dinding (wall_1, wall_2, wall_3) dengan `userData.collidable = true`
- **Collision resolution**: Push-out + recheck (handles corner cases)

### Kontrol:
| Tombol | Fungsi |
|--------|--------|
| W/A/S/D | Berjalan |
| Shift | Lari (Sprint) — standing only |
| C | Toggle Crouch → Crawl → Standing |
| Ctrl | Crawl shortcut |
| Space | Lompat — standing only |
| + / - | Sensitivitas mouse |
| ESC | Lepas kursor + exit fullscreen |

### Teknologi:
- Three.js v0.160.0 | Pointer Lock API | Keyboard Lock API | Fullscreen API

### Download:
- `fps game.zip` — Source code + Screenshot + GIF demo
