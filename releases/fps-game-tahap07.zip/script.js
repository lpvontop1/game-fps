/* ============================================================
   script.js — FPS Game Tahap 07: Collision Detection Dasar
   Bug fixes: Crosshair centered + Ctrl+W blocked (Keyboard Lock API)
   + Tahap 01-06 + AABB collision with wall slide
   ============================================================ */

// ── Konfigurasi ──────────────────────────────────────────────
const CONFIG = {
  // Camera
  cameraFOV: 75,
  cameraNear: 0.1,
  cameraFar: 1000,
  cameraStartY: 1.7,
  cameraStartZ: 5,

  // Scene
  backgroundColor: 0xcccccc,
  groundWidth: 200,
  groundHeight: 200,
  groundColor: 0x555555,

  // Renderer
  antialias: true,

  // Grid
  showGrid: true,
  gridSize: 200,
  gridDivisions: 200,
  gridColor1: 0x444444,
  gridColor2: 0x888888,

  // ── Tahap 02: Movement ────────────────────────────────────
  walkSpeed: 5.0,
  playerHeight: 1.7,
  movementSmoothing: 0.85,

  // ── Tahap 06: Mouse Look ──────────────────────────────────
  mouseSensitivity: 0.002,
  mouseSensitivityMin: 0.0005,
  mouseSensitivityMax: 0.01,
  mouseSensitivityStep: 0.0005,
  mouseSmoothing: 0.6,
  mouseSmoothBuffer: 4,

  // ── Tahap 03: Jump Physics ────────────────────────────────
  gravity: -9.8,
  jumpForce: 5.0,
  groundLevel: 1.7,

  // ── Tahap 04: Sprint & Stamina ────────────────────────────
  sprintSpeed: 9.0,
  staminaMax: 100,
  staminaDrain: 20,
  staminaRecovery: 10,

  // ── Tahap 05: Crouch & Crawl ──────────────────────────────
  crouchSpeed: 3.0,
  crawlSpeed: 2.0,
  crouchHeight: 0.9,
  crawlHeight: 0.4,
  standHeight: 1.7,
  crouchTransitionLerp: 0.12,

  // ── Tahap 07: Collision Detection ─────────────────────────
  playerRadius: 0.5,            // bounding radius horizontal pemain
  collisionEnabled: true,       // toggle collision on/off
};

// ── Variabel Global ─────────────────────────────────────────
let scene, camera, renderer;
let clock;

// ── Input State ─────────────────────────────────────────────
const keys = {
  w: false, a: false, s: false, d: false,
  space: false, shift: false, c: false, control: false,
};

const velocity = new THREE.Vector3(0, 0, 0);
let velocityY = 0;
let isGrounded = true;

// ── Sprint & Stamina ───────────────────────────────────────
let stamina = CONFIG.staminaMax;
let isSprinting = false;
let isExhausted = false;
let exhaustionTimer = 0;
const EXHAUSTION_COOLDOWN = 1.5;

// ── Crouch & Crawl ─────────────────────────────────────────
let stance = 'standing';
let targetCameraY = CONFIG.standHeight;
let crouchJustPressed = false;

// ── Mouse Look ─────────────────────────────────────────────
let yaw = 0;
let pitch = 0;
const PITCH_LIMIT = Math.PI / 2 - 0.01;
let mouseBufferX = [];
let mouseBufferY = [];
let mouseSensitivity = CONFIG.mouseSensitivity;

// Pointer Lock & Fullscreen state
let isPointerLocked = false;
let isFullscreen = false;

// ── Collision Detection (Tahap 07) ─────────────────────────
// Array of collidable AABBs: { minX, maxX, minZ, maxZ, minY, maxY }
let collidableBoxes = [];

// ── DOM Elements ────────────────────────────────────────────
const debugInfo = document.getElementById('debug-info');
const loadingScreen = document.getElementById('loading-screen');
const lockPrompt = document.getElementById('lock-prompt');
const jumpIndicator = document.getElementById('jump-indicator');
const staminaBar = document.getElementById('stamina-bar');
const staminaFill = document.getElementById('stamina-fill');
const staminaText = document.getElementById('stamina-text');
const crouchIndicator = document.getElementById('crouch-indicator');
const crosshair = document.getElementById('crosshair');
const sensitivityIndicator = document.getElementById('sensitivity-indicator');

// ── Input Handling ──────────────────────────────────────────
function setupInputHandlers() {
  window.addEventListener('keydown', (e) => {
    // ── BUG FIX: Block ALL browser shortcuts saat pointer lock ──
    // Multi-layer defense:
    // 1. e.preventDefault() + stopPropagation on capture phase
    // 2. Keyboard Lock API (locks all keys in fullscreen)
    // 3. beforeunload handler
    if (isPointerLocked) {
      e.preventDefault();
      e.stopImmediatePropagation();
    }

    const key = e.key.toLowerCase();

    if (key === ' ' || key === 'spacebar') {
      keys.space = true;
    } else if (key === 'shift') {
      keys.shift = true;
    } else if (key === 'control') {
      keys.control = true;
    } else if (key === 'c') {
      if (!keys.c) crouchJustPressed = true;
      keys.c = true;
    } else if (key in keys) {
      keys[key] = true;
    }

    // Adjustable sensitivity
    if (isPointerLocked) {
      if (key === '=' || key === '+' || key === 'numpadadd') {
        mouseSensitivity = Math.min(CONFIG.mouseSensitivityMax, mouseSensitivity + CONFIG.mouseSensitivityStep);
        showSensitivityIndicator();
      } else if (key === '-' || key === 'numpadsubtract') {
        mouseSensitivity = Math.max(CONFIG.mouseSensitivityMin, mouseSensitivity - CONFIG.mouseSensitivityStep);
        showSensitivityIndicator();
      }
    }
  }, true); // capture phase

  window.addEventListener('keyup', (e) => {
    const key = e.key.toLowerCase();
    if (key === ' ' || key === 'spacebar') keys.space = false;
    else if (key === 'shift') keys.shift = false;
    else if (key === 'control') keys.control = false;
    else if (key === 'c') keys.c = false;
    else if (key in keys) keys[key] = false;
  });

  window.addEventListener('blur', () => {
    Object.keys(keys).forEach(k => keys[k] = false);
  });

  // ── BUG FIX: beforeunload handler ──────────────────────────
  // Mencegah browser menutup/reload tab saat game aktif
  window.addEventListener('beforeunload', (e) => {
    if (isPointerLocked) {
      e.preventDefault();
      e.returnValue = 'Game masih berjalan! Yakin ingin keluar?';
      return e.returnValue;
    }
  });

  // ── Pointer Lock + Fullscreen (untuk Keyboard Lock API) ───
  const canvas = renderer.domElement;

  async function requestLock() {
    if (!isPointerLocked) {
      // Request fullscreen first (required for Keyboard Lock API)
      try {
        if (!document.fullscreenElement) {
          await document.documentElement.requestFullscreen();
          isFullscreen = true;
        }
      } catch (err) {
        // Fullscreen mungkin ditolak, lanjutkan tanpa
      }

      canvas.requestPointerLock();

      // BUG FIX: Keyboard Lock API (Chrome 94+)
      // Lock semua keyboard key agar browser shortcut tidak aktif
      // Hanya bisa saat fullscreen + pointer lock
      try {
        if (navigator.keyboard && navigator.keyboard.lock) {
          await navigator.keyboard.lock();
        }
      } catch (err) {
        // Keyboard Lock mungkin tidak didukung, fallback ke e.preventDefault()
      }
    }
  }

  canvas.addEventListener('click', requestLock);
  if (lockPrompt) {
    lockPrompt.addEventListener('click', requestLock);
  }

  document.addEventListener('pointerlockchange', () => {
    isPointerLocked = document.pointerLockElement === canvas;
    if (isPointerLocked) {
      if (lockPrompt) lockPrompt.style.display = 'none';
    } else {
      if (lockPrompt) lockPrompt.style.display = 'flex';
      keys.shift = false;
      keys.c = false;
      keys.control = false;
      if (stance !== 'standing') {
        stance = 'standing';
        targetCameraY = CONFIG.standHeight;
      }
      // Exit fullscreen saat pointer unlock (ESC)
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
    }
  });

  document.addEventListener('fullscreenchange', () => {
    isFullscreen = !!document.fullscreenElement;
  });

  // ── Mouse movement with smoothing ─────────────────────────
  document.addEventListener('mousemove', (e) => {
    if (!isPointerLocked) return;

    const rawX = e.movementX || 0;
    const rawY = e.movementY || 0;

    mouseBufferX.push(rawX);
    mouseBufferY.push(rawY);
    while (mouseBufferX.length > CONFIG.mouseSmoothBuffer) {
      mouseBufferX.shift();
      mouseBufferY.shift();
    }

    const smoothX = mouseBufferX.reduce((a, b) => a + b, 0) / mouseBufferX.length;
    const smoothY = mouseBufferY.reduce((a, b) => a + b, 0) / mouseBufferY.length;

    const sm = CONFIG.mouseSmoothing;
    const finalX = rawX * (1 - sm) + smoothX * sm;
    const finalY = rawY * (1 - sm) + smoothY * sm;

    yaw -= finalX * mouseSensitivity;
    pitch -= finalY * mouseSensitivity;
    pitch = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, pitch));

    camera.rotation.order = 'YXZ';
    camera.rotation.set(pitch, yaw, 0);
  });
}

// ── Sensitivity Indicator ──────────────────────────────────
let sensitivityTimeout = null;
function showSensitivityIndicator() {
  if (sensitivityIndicator) {
    const pct = ((mouseSensitivity - CONFIG.mouseSensitivityMin) /
                 (CONFIG.mouseSensitivityMax - CONFIG.mouseSensitivityMin) * 100);
    sensitivityIndicator.textContent = `SENS: ${mouseSensitivity.toFixed(4)} (${Math.round(pct)}%)`;
    sensitivityIndicator.style.opacity = '1';
    sensitivityIndicator.style.display = 'block';
    if (sensitivityTimeout) clearTimeout(sensitivityTimeout);
    sensitivityTimeout = setTimeout(() => {
      if (sensitivityIndicator) {
        sensitivityIndicator.style.opacity = '0';
        setTimeout(() => { if (sensitivityIndicator) sensitivityIndicator.style.display = 'none'; }, 400);
      }
    }, 2000);
  }
}

// ── Dynamic Crosshair (BUG FIX: tetap di tengah!) ─────────
function updateCrosshair() {
  if (!crosshair) return;

  const isMoving = keys.w || keys.a || keys.s || keys.d;
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);

  // Spread: melebar dari pusat, TIDAK bergeser
  let spread = 0;
  if (isSprinting) spread = 8;
  else if (speed > 2) spread = 4;
  else if (isMoving) spread = 2;

  if (stance === 'crouching') spread = Math.max(0, spread - 2);
  if (stance === 'crawling') spread = 0;

  crosshair.style.setProperty('--spread', spread + 'px');

  if (stance === 'crawling') {
    crosshair.style.setProperty('--ch-color', 'rgba(0, 255, 100, 0.9)');
  } else if (stance === 'crouching') {
    crosshair.style.setProperty('--ch-color', 'rgba(100, 255, 100, 0.9)');
  } else if (isSprinting) {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 200, 50, 0.9)');
  } else {
    crosshair.style.setProperty('--ch-color', 'rgba(255, 255, 255, 0.8)');
  }
}

// ── Inisialisasi ────────────────────────────────────────────
function init() {
  clock = new THREE.Clock();

  // Scene
  scene = new THREE.Scene();
  scene.background = new THREE.Color(CONFIG.backgroundColor);
  scene.fog = new THREE.Fog(CONFIG.backgroundColor, 50, 150);

  // Camera
  camera = new THREE.PerspectiveCamera(
    CONFIG.cameraFOV, window.innerWidth / window.innerHeight,
    CONFIG.cameraNear, CONFIG.cameraFar
  );
  camera.position.set(0, CONFIG.cameraStartY, CONFIG.cameraStartZ);
  camera.rotation.order = 'YXZ';
  camera.lookAt(0, CONFIG.cameraStartY, 0);
  yaw = 0;
  pitch = 0;

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: CONFIG.antialias });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.shadowMap.enabled = false;
  document.body.appendChild(renderer.domElement);

  // Ground Plane
  const groundGeometry = new THREE.PlaneGeometry(CONFIG.groundWidth, CONFIG.groundHeight);
  const groundMaterial = new THREE.MeshStandardMaterial({
    color: CONFIG.groundColor, side: THREE.DoubleSide, roughness: 0.9, metalness: 0.1,
  });
  const ground = new THREE.Mesh(groundGeometry, groundMaterial);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = 0;
  ground.name = 'ground';
  scene.add(ground);

  // Grid Helper
  if (CONFIG.showGrid) {
    const grid = new THREE.GridHelper(CONFIG.gridSize, CONFIG.gridDivisions, CONFIG.gridColor1, CONFIG.gridColor2);
    grid.position.y = 0.01;
    grid.name = 'grid';
    scene.add(grid);
  }

  // Reference Objects
  addReferenceObjects();

  // Tahap 07: Collision obstacles
  addCollisionObstacles();

  // Lights
  scene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight.position.set(50, 100, 50);
  scene.add(dirLight);

  // Setup Input
  setupInputHandlers();

  // Resize Handler
  window.addEventListener('resize', onWindowResize);

  // Hide Loading Screen
  if (loadingScreen) {
    loadingScreen.classList.add('hidden');
    setTimeout(() => { if (loadingScreen && loadingScreen.parentNode) loadingScreen.parentNode.removeChild(loadingScreen); }, 600);
  }

  if (lockPrompt) lockPrompt.style.display = 'flex';

  // Start Render Loop
  animate();
}

// ── Reference Objects ───────────────────────────────────────
function addReferenceObjects() {
  const boxGeometry = new THREE.BoxGeometry(2, 2, 2);
  const colors = [0xff4444, 0x44ff44, 0x4444ff, 0xffff44, 0xff44ff, 0x44ffff];
  const positions = [
    [8, 1, -10], [-8, 1, -10], [0, 1, -20],
    [12, 1, -5], [-12, 1, -5], [0, 1, 5],
  ];
  positions.forEach((pos, i) => {
    const mat = new THREE.MeshStandardMaterial({ color: colors[i], roughness: 0.5, metalness: 0.2 });
    const box = new THREE.Mesh(boxGeometry, mat);
    box.position.set(pos[0], pos[1], pos[2]);
    box.name = 'refBox_' + i;
    scene.add(box);
  });

  const pillarGeo = new THREE.CylinderGeometry(0.5, 0.5, 4, 8);
  const pillarMat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7 });
  const pillarPositions = [
    [20, 2, -30], [-20, 2, -30], [20, 2, 20], [-20, 2, 20],
    [0, 2, -40], [30, 2, -10], [-30, 2, -10],
  ];
  pillarPositions.forEach((pos, i) => {
    const pillar = new THREE.Mesh(pillarGeo, pillarMat);
    pillar.position.set(pos[0], pos[1], pos[2]);
    pillar.name = 'pillar_' + i;
    scene.add(pillar);
  });
}

// ── Tahap 07: Add Collision Obstacles ──────────────────────
function addCollisionObstacles() {
  const wallMat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.7 });

  // Dinding 1: dinding panjang vertikal di x=6 (dekat player start z=5)
  const wall1Geo = new THREE.BoxGeometry(0.5, 3, 20);
  const wall1 = new THREE.Mesh(wall1Geo, wallMat);
  wall1.position.set(6, 1.5, 0);  // spans z: -10 to 10
  wall1.name = 'wall_1';
  wall1.userData.collidable = true;
  scene.add(wall1);

  // Dinding 2: dinding horizontal di z=-5
  const wall2Geo = new THREE.BoxGeometry(14, 3, 0.5);
  const wall2 = new THREE.Mesh(wall2Geo, wallMat);
  wall2.position.set(0, 1.5, -5);
  wall2.name = 'wall_2';
  wall2.userData.collidable = true;
  scene.add(wall2);

  // Dinding 3: box obstacle (2x3x2) di posisi (-3, 1.5, 8)
  const wall3Geo = new THREE.BoxGeometry(2, 3, 2);
  const wall3 = new THREE.Mesh(wall3Geo, wallMat);
  wall3.position.set(-3, 1.5, 8);
  wall3.name = 'wall_3';
  wall3.userData.collidable = true;
  scene.add(wall3);

  // Build AABB collision boxes dari mesh yang collidable
  rebuildCollisionBoxes();
}

// ── Tahap 07: Rebuild Collision AABBs dari scene ──────────
function rebuildCollisionBoxes() {
  collidableBoxes = [];
  scene.traverse((obj) => {
    if (obj.userData && obj.userData.collidable && obj.isMesh) {
      const box = new THREE.Box3().setFromObject(obj);
      collidableBoxes.push({
        name: obj.name,
        minX: box.min.x, maxX: box.max.x,
        minY: box.min.y, maxY: box.max.y,
        minZ: box.min.z, maxZ: box.max.z,
      });
    }
  });
}

// ── Tahap 07: Collision Check (AABB vs circle on XZ plane) ─
// Pemain = circle (radius) pada XZ plane, height check pada Y
function checkCollision(newX, newZ, radius) {
  const r = radius;
  for (let i = 0; i < collidableBoxes.length; i++) {
    const box = collidableBoxes[i];

    // Cek apakah player circle overlap dengan AABB pada XZ plane
    // Clamp circle center ke AABB → jika distance < radius → collision
    const closestX = Math.max(box.minX, Math.min(newX, box.maxX));
    const closestZ = Math.max(box.minZ, Math.min(newZ, box.maxZ));

    const dx = newX - closestX;
    const dz = newZ - closestZ;
    const distSq = dx * dx + dz * dz;

    if (distSq < r * r) {
      // Collision detected → return push direction
      const dist = Math.sqrt(Math.max(distSq, 0.0001));
      return {
        collided: true,
        // Normal push: arah dari closest point ke player center
        pushX: dx / dist,
        pushZ: dz / dist,
        // Jarak overlap
        overlap: r - dist,
        boxName: box.name,
      };
    }
  }
  return { collided: false };
}

// ── Tahap 07: Collision Resolution with Wall Slide ─────────
// Jika collision terjadi, push pemain keluar dan biarkan
// komponen velocity yang sejajar dinding tetap (wall slide)
function resolveCollision(newX, newZ, radius) {
  const result = checkCollision(newX, newZ, radius);
  if (!result.collided) return { x: newX, z: newZ, collided: false };

  // Push pemain keluar dari AABB
  const pushX = result.pushX * result.overlap;
  const pushZ = result.pushZ * result.overlap;

  let resolvedX = newX + pushX;
  let resolvedZ = newZ + pushZ;

  // Verifikasi: cek lagi apakah posisi setelah push masih collide
  // (untuk kasus corner antara 2 boxes)
  const recheck = checkCollision(resolvedX, resolvedZ, radius);
  if (recheck.collided) {
    resolvedX += recheck.pushX * recheck.overlap;
    resolvedZ += recheck.pushZ * recheck.overlap;
  }

  // Wall slide: hapus komponen velocity yang menuju dinding
  // Dot product velocity dengan push normal
  const dot = velocity.x * result.pushX + velocity.z * result.pushZ;
  if (dot < 0) {
    // Velocity menuju dinding → hapus komponen tersebut
    velocity.x -= dot * result.pushX;
    velocity.z -= dot * result.pushZ;
  }

  return { x: resolvedX, z: resolvedZ, collided: true };
}

// ── Resize Handler ──────────────────────────────────────────
function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

// ── Crouch / Crawl ─────────────────────────────────────────
function updateCrouch(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  if (crouchJustPressed) {
    crouchJustPressed = false;
    switch (stance) {
      case 'standing':  stance = 'crouching'; targetCameraY = CONFIG.crouchHeight; break;
      case 'crouching': stance = 'crawling';  targetCameraY = CONFIG.crawlHeight;  break;
      case 'crawling':  stance = 'standing';  targetCameraY = CONFIG.standHeight;  break;
    }
  }

  if (keys.control && stance !== 'crawling') {
    stance = 'crawling';
    targetCameraY = CONFIG.crawlHeight;
  }

  if (isGrounded) {
    const currentY = camera.position.y;
    const lerpFactor = 1 - Math.pow(1 - CONFIG.crouchTransitionLerp, dt * 60);
    camera.position.y = currentY + (targetCameraY - currentY) * lerpFactor;
    if (Math.abs(camera.position.y - targetCameraY) < 0.01) camera.position.y = targetCameraY;
    CONFIG.groundLevel = targetCameraY;
  }

  if (crouchIndicator) {
    switch (stance) {
      case 'standing':  crouchIndicator.textContent = 'STANDING';  crouchIndicator.className = 'standing';  break;
      case 'crouching': crouchIndicator.textContent = 'CROUCHING'; crouchIndicator.className = 'crouching'; break;
      case 'crawling':  crouchIndicator.textContent = 'CRAWLING';  crouchIndicator.className = 'crawling';  break;
    }
  }
}

// ── Sprint & Stamina ───────────────────────────────────────
function updateSprint(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);
  const isMoving = keys.w || keys.a || keys.s || keys.d;

  if (isExhausted) {
    exhaustionTimer -= dt;
    if (exhaustionTimer <= 0) { isExhausted = false; exhaustionTimer = 0; }
  }

  const canSprint = keys.shift && isGrounded && stamina > 0 && isMoving && !isExhausted && stance === 'standing';

  if (canSprint) {
    isSprinting = true;
    stamina -= CONFIG.staminaDrain * dt;
    if (stamina <= 0) { stamina = 0; isExhausted = true; exhaustionTimer = EXHAUSTION_COOLDOWN; }
  } else {
    isSprinting = false;
    stamina += CONFIG.staminaRecovery * dt;
    if (stamina > CONFIG.staminaMax) stamina = CONFIG.staminaMax;
  }

  if (staminaFill) {
    const pct = (stamina / CONFIG.staminaMax) * 100;
    staminaFill.style.width = pct + '%';
    staminaFill.style.background = pct > 60 ? '#00ff00' : pct > 30 ? '#ffaa00' : '#ff3300';
  }
  if (staminaText) staminaText.textContent = Math.round(stamina) + '%';
  if (staminaBar) {
    if (stamina <= 0 && keys.shift) staminaBar.classList.add('exhausted');
    else staminaBar.classList.remove('exhausted');
  }
}

// ── Horizontal Movement + Collision (Tahap 07) ─────────────
function updateMovement(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  let currentSpeed;
  if (stance === 'crawling') currentSpeed = CONFIG.crawlSpeed;
  else if (stance === 'crouching') currentSpeed = CONFIG.crouchSpeed;
  else if (isSprinting) currentSpeed = CONFIG.sprintSpeed;
  else currentSpeed = CONFIG.walkSpeed;

  const cameraDirection = new THREE.Vector3();
  camera.getWorldDirection(cameraDirection);
  const forwardXZ = new THREE.Vector3(cameraDirection.x, 0, cameraDirection.z);
  const forwardLen = forwardXZ.length();

  let forward, right;
  if (forwardLen > 0.001) {
    forward = forwardXZ.normalize();
    right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(0, 1, 0)).normalize();
  } else {
    forward = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
    right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  }

  const targetVelocity = new THREE.Vector3(0, 0, 0);
  if (keys.w) targetVelocity.add(forward);
  if (keys.s) targetVelocity.sub(forward);
  if (keys.d) targetVelocity.add(right);
  if (keys.a) targetVelocity.sub(right);
  if (targetVelocity.lengthSq() > 0) targetVelocity.normalize();
  targetVelocity.multiplyScalar(currentSpeed);

  const smoothing = CONFIG.movementSmoothing;
  const lerpFactor = 1 - Math.pow(smoothing, dt * 60);
  velocity.x += (targetVelocity.x - velocity.x) * lerpFactor;
  velocity.z += (targetVelocity.z - velocity.z) * lerpFactor;

  // ── Tahap 07: Apply movement dengan collision check ───────
  let newX = camera.position.x + velocity.x * dt;
  let newZ = camera.position.z + velocity.z * dt;

  if (CONFIG.collisionEnabled && collidableBoxes.length > 0) {
    const result = resolveCollision(newX, newZ, CONFIG.playerRadius);
    camera.position.x = result.x;
    camera.position.z = result.z;
  } else {
    camera.position.x = newX;
    camera.position.z = newZ;
  }
}

// ── Jump / Vertical Physics ────────────────────────────────
function updateJump(deltaTime) {
  const dt = Math.min(deltaTime, 0.1);

  if (keys.space && isGrounded && stance === 'standing') {
    velocityY = CONFIG.jumpForce;
    isGrounded = false;
    isSprinting = false;
  }

  if (!isGrounded) {
    velocityY += CONFIG.gravity * dt;
    camera.position.y += velocityY * dt;
  }

  if (camera.position.y <= CONFIG.groundLevel) {
    camera.position.y = CONFIG.groundLevel;
    velocityY = 0;
    isGrounded = true;
  }

  if (jumpIndicator) {
    jumpIndicator.textContent = isGrounded ? 'GROUNDED' : 'AIRBORNE';
    jumpIndicator.className = isGrounded ? 'grounded' : 'airborne';
  }
}

// ── Render Loop ─────────────────────────────────────────────
function animate() {
  requestAnimationFrame(animate);
  const deltaTime = clock.getDelta();

  updateCrouch(deltaTime);
  updateSprint(deltaTime);
  updateMovement(deltaTime);
  updateJump(deltaTime);
  updateCrosshair();
  updateDebugInfo(deltaTime);

  renderer.render(scene, camera);
}

// ── Debug Info ──────────────────────────────────────────────
function updateDebugInfo(deltaTime) {
  if (!debugInfo) return;

  const fps = deltaTime > 0 ? (1 / deltaTime).toFixed(0) : '—';
  const speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z).toFixed(1);

  const keysPressed = [];
  if (keys.w) keysPressed.push('W');
  if (keys.a) keysPressed.push('A');
  if (keys.s) keysPressed.push('S');
  if (keys.d) keysPressed.push('D');
  if (keys.space) keysPressed.push('SPACE');
  if (keys.shift) keysPressed.push('SHIFT');
  if (keys.c) keysPressed.push('C');
  if (keys.control) keysPressed.push('CTRL');

  let stanceLabel;
  switch (stance) {
    case 'standing':  stanceLabel = isSprinting ? 'SPRINTING' : isExhausted ? 'EXHAUSTED' : 'STANDING'; break;
    case 'crouching': stanceLabel = 'CROUCHING'; break;
    case 'crawling':  stanceLabel = 'CRAWLING';  break;
  }

  let speedLabel;
  switch (stance) {
    case 'crawling':  speedLabel = 'CRAW';  break;
    case 'crouching': speedLabel = 'CROUCH'; break;
    default:          speedLabel = isSprinting ? 'SPRINT' : 'WALK'; break;
  }

  const yawDeg = ((yaw * 180 / Math.PI) % 360).toFixed(0);
  const pitchDeg = (pitch * 180 / Math.PI).toFixed(0);

  debugInfo.innerHTML =
    `TAHAP 07 — Collision Detection<br>` +
    `FPS: ${fps} | Speed: ${speed} u/s [${speedLabel}]<br>` +
    `Pos: (${camera.position.x.toFixed(1)}, ${camera.position.y.toFixed(1)}, ${camera.position.z.toFixed(1)})<br>` +
    `Yaw: ${yawDeg}° | Pitch: ${pitchDeg}°<br>` +
    `Stance: ${stanceLabel} | ${isGrounded ? 'GROUNDED' : 'AIRBORNE'}<br>` +
    `Walls: ${collidableBoxes.length} | Stamina: ${Math.round(stamina)}%<br>` +
    `Keys: ${keysPressed.length > 0 ? keysPressed.join('+') : '—'}`;
}

// ── Entry Point ─────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
